package vn.autobuild;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.SlabType;

/**
 * Chia công trình (đã xoay/lật) thành các layer Y từ thấp lên cao.
 * Trong mỗi layer: pha 0 = block thường + redstone, pha 1 = block phụ thuộc hướng (piston, observer...),
 * (pha 2 = nước/lava, để dành cho giai đoạn 1.5). Trong mỗi pha duyệt theo hàng rắn bò để đi ít nhất.
 */
public final class BuildPlanner {
    public static final class Target {
        public final BlockPos pos;
        public final BlockState want;
        public final Item item;
        public final int phase;
        public int order;
        public int retries, fixClicks, noPlanTicks, scaffoldTries;
        public long placedAt = -1, lastFix = -100;
        public boolean done, failed;
        public String failReason = "";

        Target(BlockPos pos, BlockState want, Item item, int phase, int order) {
            this.pos = pos; this.want = want; this.item = item; this.phase = phase; this.order = order;
        }
    }

    public static final class Layer {
        public final int index, worldY;
        public final List<Target> queue = new ArrayList<>();   // chưa đặt, đã sắp thứ tự
        public final List<Target> pending = new ArrayList<>(); // đã đặt, chờ kiểm tra blockstate
        public final List<Target> failed = new ArrayList<>();
        public int total, done;
        public boolean synced, retried;

        Layer(int index, int worldY) { this.index = index; this.worldY = worldY; }
    }

    public static final Comparator<Target> ORDER =
        Comparator.<Target>comparingInt(t -> t.phase).thenComparingInt(t -> t.order);

    public final SchematicData data;
    public final BlockPos origin;
    public final List<Layer> layers = new ArrayList<>();
    public final Map<String, Integer> skipped = new TreeMap<>();
    private final Map<Long, Target> byPos = new HashMap<>();
    public int total, done;

    public BuildPlanner(SchematicData data, BlockPos origin) {
        this.data = data;
        this.origin = origin;
        for (int y = 0; y < data.sy; y++) {
            Layer layer = new Layer(layers.size(), origin.getY() + y);
            for (int z = 0; z < data.sz; z++) {
                for (int x = 0; x < data.sx; x++) {
                    BlockState s = data.get(x, y, z);
                    if (s == null) continue;
                    String why = skipReason(s);
                    if (why != null) { skipped.merge(why, 1, Integer::sum); continue; }
                    int order = z * 10000 + ((z & 1) == 0 ? x : (data.sx - 1 - x)); // hàng rắn bò
                    Target t = new Target(origin.offset(x, y, z), s, s.getBlock().asItem(), phaseOf(s), order);
                    layer.queue.add(t);
                    byPos.put(t.pos.asLong(), t);
                }
            }
            if (layer.queue.isEmpty()) continue;
            layer.queue.sort(ORDER);
            layer.total = layer.queue.size();
            total += layer.total;
            layers.add(layer);
        }
    }

    public Target targetAt(BlockPos p) { return byPos.get(p.asLong()); }

    /** Công trình có muốn một block ở ô này không (dùng để không kê giàn vào ô công trình). */
    public boolean wants(BlockPos p) {
        return data.get(p.getX() - origin.getX(), p.getY() - origin.getY(), p.getZ() - origin.getZ()) != null;
    }

    /** null = đặt được; còn lại là lý do bỏ qua. */
    public static String skipReason(BlockState s) {
        String id = StateUtil.id(s);
        if (id.equals("minecraft:water") || id.equals("minecraft:lava")) return "nước/lava (làm ở giai đoạn 1.5)";
        if (id.equals("minecraft:piston_head") || id.equals("minecraft:moving_piston")) return "đầu piston (tự sinh)";
        if (s.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)
                && s.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) return "nửa trên cửa/cây cao (tự sinh)";
        if (s.hasProperty(BlockStateProperties.BED_PART)
                && s.getValue(BlockStateProperties.BED_PART) == BedPart.HEAD) return "đầu giường (tự sinh)";
        if (s.hasProperty(BlockStateProperties.SLAB_TYPE)
                && s.getValue(BlockStateProperties.SLAB_TYPE) == SlabType.DOUBLE) return "slab đôi (chưa hỗ trợ)";
        if (s.getBlock().asItem() == Items.AIR) return "không có item để đặt (" + id + ")";
        return null;
    }

    static int phaseOf(BlockState s) {
        if (s.hasProperty(BlockStateProperties.STAIRS_SHAPE)) return 0; // stairs coi như block thường
        if (s.hasProperty(BlockStateProperties.FACING) || s.hasProperty(BlockStateProperties.HORIZONTAL_FACING)
                || s.hasProperty(BlockStateProperties.FACING_HOPPER) || s.hasProperty(BlockStateProperties.ATTACH_FACE)) return 1;
        return 0;
    }
}
