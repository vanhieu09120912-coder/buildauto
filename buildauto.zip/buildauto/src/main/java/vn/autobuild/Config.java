package vn.autobuild;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** Cấu hình lưu ở config/autobuild/config.json. Sửa file rồi gõ /autobuild reload (hoặc vào lại game). */
public final class Config {
    /** Tầm với (block) tính từ mắt. Mặc định 4.0 < 4.5 của vanilla. Hạ thấp nếu server soi chặt. */
    public double reach = 4.0;
    /** Số block tối đa đặt trong 1 tick. */
    public int blocksPerTick = 3;
    /** Cứ mỗi N tick mới đặt một đợt (1 = mỗi tick). Tăng lên để chậm lại. */
    public int placeIntervalTicks = 1;
    /** Sau bao nhiêu tick thì kiểm tra lại blockstate vừa đặt. */
    public int verifyDelayTicks = 6;
    /** Số lần thử lại một ô trước khi bỏ qua và xử lý ở cuối layer. */
    public int maxRetries = 3;
    /** Độ cao bay lơ lửng phía trên layer đang xây. */
    public double hoverHeight = 2.0;
    /** Tốc độ bay (block/tick). 0.25 ~ 5 block/giây. */
    public double flySpeed = 0.25;
    /** Không tiến triển sau N giây thì lập lại kế hoạch. */
    public int stuckSeconds = 8;
    /** Dừng khi máu dưới mức này. */
    public float minHealth = 6.0f;
    /** Chỉ click vào điểm mà tia nhìn từ mắt thực sự chạm tới (raycast). */
    public boolean requireRaycast = true;
    /** Góc lệch tối đa giữa hướng nhìn và điểm click. 180 = không giới hạn. */
    public double maxLookAngleDeg = 180.0;
    /** Block hơi thiếu mặt tựa thì kê giàn tạm rồi dọn đi. */
    public boolean useScaffold = true;
    public String scaffoldBlock = "minecraft:dirt";

    public static Config INSTANCE = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("autobuild"); }
    public static Path schematicDir() { return dir().resolve("schematics"); }

    public static void load() {
        try {
            Files.createDirectories(schematicDir());
            Path f = dir().resolve("config.json");
            if (Files.exists(f)) {
                Config c = GSON.fromJson(Files.readString(f), Config.class);
                if (c != null) INSTANCE = c;
            }
            Files.writeString(f, GSON.toJson(INSTANCE)); // ghi lại để có đủ các trường mới
        } catch (Exception e) {
            System.err.println("[AutoBuild] Không đọc được config: " + e);
        }
    }
}
