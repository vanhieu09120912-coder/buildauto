package vn.autobuild;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import vn.autobuild.BuildPlanner.Layer;
import vn.autobuild.BuildPlanner.Target;

/** Bộ điều khiển chính: chạy mỗi tick, xây từng layer từ dưới lên. */
public final class BuildController {
    public enum State { IDLE, BUILDING, PAUSED, DONE }

    public static final BuildController I = new BuildController();

    public SchematicData raw;
    public String fileName = "";
    public BlockPos anchor;          // góc có X,Y,Z nhỏ nhất của công trình trong thế giới
    public int rotDeg = 0;
    public Mirror mirror = Mirror.NONE;
    public BuildPlanner planner;
    public State state = State.IDLE;
    public String note = "";

    private int layerIdx, progressCounter, lastCounter, stuckCount;
    private long tickNo, lastProgress;
    private final PathMover mover = new PathMover();
    private final List<BlockPos> scaffolds = new ArrayList<>();

    // ---------------------------------------------------------------- điều khiển

    public void load(Path file) throws IOException {
        raw = SchematicLoader.load(file);
        fileName = file.getFileName().toString();
        planner = null;
        state = State.IDLE;
        note = "";
    }

    public Rotation rotation() {
        return switch (rotDeg) {
            case 90 -> Rotation.CLOCKWISE_90;
            case 180 -> Rotation.CLOCKWISE_180;
            case 270 -> Rotation.COUNTERCLOCKWISE_90;
            default -> Rotation.NONE;
        };
    }

    /** @return null nếu bắt đầu được, ngược lại là thông báo lỗi. */
    public String start() {
        if (raw == null) return "Chưa load schematic. Dùng: /autobuild load <tên file>";
        if (anchor == null) return "Chưa đặt gốc. Đứng ở góc thấp nhất rồi gõ: /autobuild anchor";
        SchematicData t = SchematicLoader.transform(raw, rotation(), mirror);
        planner = new BuildPlanner(t, anchor);
        layerIdx = 0; tickNo = 0; lastProgress = 0; stuckCount = 0; progressCounter = 0; lastCounter = 0;
        scaffolds.clear();
        mover.clear();
        state = State.BUILDING;
        note = "";
        return null;
    }

    public void pause(String why) {
        if (state != State.BUILDING) return;
        state = State.PAUSED;
        note = why;
        mover.clear();
        msg("§e[AutoBuild] Tạm dừng: " + why);
    }

    public String resume() {
        if (planner == null) return "Chưa start.";
        if (state != State.PAUSED) return "Không đang tạm dừng.";
        state = State.BUILDING;
        note = "";
        lastProgress = tickNo;
        return null;
    }

    public void stop() {
        state = State.IDLE;
        note = "";
        mover.clear();
    }

    public String gotoLayer(int n) {
        if (planner == null) return "Chưa start.";
        if (n < 1 || n > planner.layers.size()) return "Layer phải từ 1 đến " + planner.layers.size();
        layerIdx = n - 1;
        planner.layers.get(layerIdx).synced = false;
        mover.clear();
        return null;
    }

    public String statusText() {
        if (planner == null) return "Trạng thái: " + state + (raw != null ? " | đã load " + fileName : " | chưa load");
        return "Trạng thái: " + state + " | Tầng " + Math.min(layerIdx + 1, planner.layers.size()) + "/" + planner.layers.size()
            + " | " + planner.done + "/" + planner.total + (note.isEmpty() ? "" : " | " + note);
    }

    // ---------------------------------------------------------------- vòng lặp mỗi tick

    public void tick(Minecraft mc) {
        if (state != State.BUILDING || planner == null) return;
        LocalPlayer p = mc.player;
        ClientLevel lv = mc.level;
        if (p == null || lv == null || mc.gameMode == null) { state = State.PAUSED; note = "mất kết nối"; return; }
        Config cfg = Config.INSTANCE;
        if (p.getHealth() < cfg.minHealth) { pause("máu thấp"); return; }
        if (!p.getAbilities().mayfly) { pause("giai đoạn 1 cần creative/được phép bay (đi bộ làm ở giai đoạn 1.5)"); return; }
        tickNo++;

        if (layerIdx >= planner.layers.size()) { finish(); return; }
        Layer L = planner.layers.get(layerIdx);
        if (!L.synced) { sync(lv, L); L.synced = true; }

        verify(mc, L);
        cleanupScaffolds(mc);

        if (L.queue.isEmpty() && L.pending.isEmpty()) { endOfLayer(L); return; }

        Vec3 eye = p.getEyePosition();
        int pendMin = Integer.MAX_VALUE;
        for (Target t : L.pending) pendMin = Math.min(pendMin, t.phase);

        // ---- đặt block trong tầm với
        int placed = 0, scanned = 0;
        List<Target> toBack = new ArrayList<>();
        boolean canPlace = tickNo % Math.max(1, cfg.placeIntervalTicks) == 0;
        Iterator<Target> it = L.queue.iterator();
        while (canPlace && it.hasNext() && placed < cfg.blocksPerTick && scanned < 96) {
            Target t = it.next();
            scanned++;
            if (t.phase > pendMin) break;                         // chờ pha trước kiểm tra xong
            if (eye.distanceTo(t.pos.getCenter()) > cfg.reach) continue;

            BlockState cur = lv.getBlockState(t.pos);
            if (StateUtil.matches(cur, t.want, StateUtil.IGNORE_FINAL)) {   // đã có sẵn đúng
                t.done = true; L.done++; planner.done++; progressCounter++; it.remove();
                continue;
            }
            if (!cur.canBeReplaced()) {                           // đang có block sai -> phá
                Placer.breakBlock(mc, t.pos);
                if (++t.noPlanTicks > 100) { it.remove(); fail(L, t, "ô bị block khác chiếm, không phá được"); }
                continue;
            }
            if (!InventoryManager.equip(mc, t.item)) {
                if (!p.getAbilities().instabuild && InventoryManager.count(p, t.item) == 0) {
                    pause("hết " + BuiltInRegistries.ITEM.getKey(t.item) + " - bỏ thêm vào túi rồi /autobuild resume (giai đoạn 2 sẽ tự mua /ah)");
                    return;
                }
                continue; // đang chờ hotbar cập nhật
            }
            PlacementSolver.Plan plan = PlacementSolver.solve(mc, t.pos, t.want, eye, cfg);
            if (plan == null) {
                if (cfg.useScaffold && t.scaffoldTries < 3 && tryScaffold(mc, t, eye)) { t.scaffoldTries++; placed++; continue; }
                if (++t.noPlanTicks > 40) {
                    t.noPlanTicks = 0;
                    it.remove();
                    if (++t.retries > cfg.maxRetries) fail(L, t, "không có mặt tựa / không đặt đúng hướng được");
                    else { t.order += 100_000_000; toBack.add(t); }
                }
                continue;
            }
            if (Placer.place(mc, plan)) {
                t.placedAt = tickNo;
                it.remove();
                L.pending.add(t);
                placed++;
                progressCounter++;
            }
        }
        if (!toBack.isEmpty()) { L.queue.addAll(toBack); L.queue.sort(BuildPlanner.ORDER); }

        // ---- di chuyển: bay tới phía trên ô kế tiếp nếu nó ngoài tầm
        if (!L.queue.isEmpty()) {
            Target front = L.queue.get(0);
            if (front.phase <= pendMin) {
                if (eye.distanceTo(front.pos.getCenter()) > cfg.reach - 0.3) {
                    mover.setGoal(PathMover.hoverPoint(lv, front.pos, cfg.hoverHeight));
                } else {
                    mover.clear();
                }
            }
        }
        mover.tick(mc, cfg);

        // ---- kẹt thì lập lại kế hoạch
        if (progressCounter != lastCounter) {
            lastCounter = progressCounter;
            lastProgress = tickNo;
        } else if (tickNo - lastProgress > cfg.stuckSeconds * 20L) {
            lastProgress = tickNo;
            stuckCount++;
            mover.clear();
            if (!L.queue.isEmpty()) {
                Target f = L.queue.remove(0);
                f.order += 100_000_000;
                if (stuckCount > 6) fail(L, f, "kẹt, không tiến triển được");
                else L.queue.add(f);
                L.queue.sort(BuildPlanner.ORDER);
            }
            msg("§c[AutoBuild] Kẹt, lập lại kế hoạch (lần " + stuckCount + ")");
            if (stuckCount > 20) { pause("kẹt quá lâu"); return; }
        }

        if (tickNo % 5 == 0) p.displayClientMessage(Component.literal(hud(L, p)), true);
    }

    // ---------------------------------------------------------------- các bước con

    /** Kiểm tra lại các ô đã đặt: đúng -> xong; chỉ lệch delay -> click chỉnh; sai -> phá và đặt lại. */
    private void verify(Minecraft mc, Layer L) {
        ClientLevel lv = mc.level;
        Config cfg = Config.INSTANCE;
        for (Iterator<Target> it = L.pending.iterator(); it.hasNext();) {
            Target t = it.next();
            BlockState cur = lv.getBlockState(t.pos);
            if (StateUtil.matches(cur, t.want, StateUtil.IGNORE_FINAL)) {
                t.done = true; L.done++; planner.done++; progressCounter++;
                it.remove();
                continue;
            }
            if (StateUtil.onlyClickFixDiffers(cur, t.want)) {
                if (t.fixClicks >= 8) { it.remove(); fail(L, t, "không chỉnh được delay/mode"); }
                else if (tickNo - t.lastFix >= 2) {
                    Placer.clickFix(mc, t.pos);
                    t.fixClicks++;
                    t.lastFix = tickNo;
                    progressCounter++;
                }
                continue;
            }
            if (tickNo - t.placedAt >= cfg.verifyDelayTicks) {
                it.remove();
                if (++t.retries > cfg.maxRetries) { fail(L, t, "blockstate sai sau nhiều lần đặt"); continue; }
                t.placedAt = -1;
                L.queue.add(t);          // vòng quét sau sẽ phá block sai (nếu có) rồi đặt lại
                L.queue.sort(BuildPlanner.ORDER);
            }
        }
    }

    private void sync(ClientLevel lv, Layer L) {
        for (Iterator<Target> it = L.queue.iterator(); it.hasNext();) {
            Target t = it.next();
            if (StateUtil.matches(lv.getBlockState(t.pos), t.want, StateUtil.IGNORE_FINAL)) {
                t.done = true; L.done++; planner.done++;
                it.remove();
            }
        }
    }

    /** Kê block tạm cạnh ô lơ lửng để có chỗ tựa (độ sâu 1). Dọn đi sau khi đặt xong. */
    private boolean tryScaffold(Minecraft mc, Target t, Vec3 eye) {
        Config cfg = Config.INSTANCE;
        Block sb = SchematicLoader.blockByName(cfg.scaffoldBlock);
        if (sb == null) return false;
        BlockState ss = sb.defaultBlockState();
        for (Direction d : Direction.values()) {
            BlockPos n = t.pos.relative(d);
            BlockState ns = mc.level.getBlockState(n);
            if (!ns.canBeReplaced() || !ns.getFluidState().isEmpty()) continue; // phải là ô trống
            if (planner.wants(n)) continue;                                     // không kê vào ô công trình cần
            if (eye.distanceTo(n.getCenter()) > cfg.reach) continue;
            if (!InventoryManager.equip(mc, sb.asItem())) return false;
            PlacementSolver.Plan sp = PlacementSolver.solve(mc, n, ss, eye, cfg);
            if (sp == null) continue;
            if (Placer.place(mc, sp)) { scaffolds.add(n); progressCounter++; return true; }
        }
        return false;
    }

    private void cleanupScaffolds(Minecraft mc) {
        for (Iterator<BlockPos> it = scaffolds.iterator(); it.hasNext();) {
            BlockPos s = it.next();
            if (mc.level.getBlockState(s).isAir()) { it.remove(); continue; }
            boolean needed = false;
            for (Direction d : Direction.values()) {
                Target t = planner.targetAt(s.relative(d));
                if (t != null && !t.done && !t.failed) { needed = true; break; }
            }
            if (!needed) Placer.breakBlock(mc, s);
        }
    }

    private void fail(Layer L, Target t, String why) {
        t.failed = true;
        t.failReason = why;
        L.failed.add(t);
        progressCounter++;
    }

    private void endOfLayer(Layer L) {
        // Các ô khó được xử lý lại một lượt ở cuối layer
        if (!L.failed.isEmpty() && !L.retried) {
            L.retried = true;
            for (Target t : L.failed) {
                t.failed = false; t.retries = 0; t.noPlanTicks = 0; t.scaffoldTries = 0; t.placedAt = -1;
                L.queue.add(t);
            }
            L.failed.clear();
            L.queue.sort(BuildPlanner.ORDER);
            msg("§e[AutoBuild] Xử lý lại các ô khó ở cuối layer #" + (layerIdx + 1));
            return;
        }
        int n = layerIdx + 1;
        if (!L.failed.isEmpty()) {
            Target f = L.failed.get(0);
            msg("§c[AutoBuild] Layer #" + n + " còn " + L.failed.size() + " ô không đặt được. Ví dụ "
                + f.pos.getX() + "," + f.pos.getY() + "," + f.pos.getZ() + ": " + f.failReason);
        }
        mover.clear();
        stuckCount = 0;
        layerIdx++;
        if (layerIdx < planner.layers.size()) msg("§a[AutoBuild] Layer #" + n + " complete, advancing to Layer #" + (n + 1));
    }

    private void finish() {
        int failed = 0;
        for (Layer l : planner.layers) failed += l.failed.size();
        state = State.DONE;
        mover.clear();
        msg("§a[AutoBuild] Xong! " + planner.done + "/" + planner.total + " block"
            + (failed > 0 ? ", §c" + failed + " ô không đặt được" : "") + ".");
    }

    private String hud(Layer L, LocalPlayer p) {
        int pct = planner.total == 0 ? 100 : (int) (100L * planner.done / planner.total);
        String st = mover.hasGoal() && !mover.arrived(p) ? "đang đi" : "đang xây";
        return "Tầng " + (layerIdx + 1) + "/" + planner.layers.size() + " | " + planner.done + "/" + planner.total
            + " (" + pct + "%) | " + st;
    }

    static void msg(String s) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(s), false);
    }
}
