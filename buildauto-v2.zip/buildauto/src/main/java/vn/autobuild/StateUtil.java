package vn.autobuild;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

public final class StateUtil {
    private StateUtil() {}

    /** Thuộc tính do hàng xóm/redstone/server quyết định, không đặt trực tiếp được -> bỏ qua khi so sánh cuối. */
    public static final Set<String> IGNORE_FINAL = Set.of(
        "waterlogged", "powered", "power", "lit", "shape", "north", "east", "south", "west",
        "up", "down", "open", "hinge", "locked", "extended", "triggered", "conditional",
        "persistent", "distance", "enabled", "attached", "in_wall", "bottom");

    /** Khi mô phỏng lúc đặt: bỏ thêm delay/mode vì repeater/comparator chỉnh bằng cách click sau khi đặt. */
    public static final Set<String> IGNORE_PLACE;
    static {
        Set<String> s = new HashSet<>(IGNORE_FINAL);
        s.add("delay");
        s.add("mode");
        IGNORE_PLACE = s;
    }

    public static boolean matches(BlockState actual, BlockState want, Set<String> ignore) {
        if (actual.getBlock() != want.getBlock()) return false;
        for (Property<?> p : want.getProperties()) {
            if (ignore.contains(p.getName())) continue;
            if (!actual.getValue(p).equals(want.getValue(p))) return false;
        }
        return true;
    }

    /** Đúng hết, chỉ lệch delay/mode -> sửa bằng cách click chuột phải. */
    public static boolean onlyClickFixDiffers(BlockState actual, BlockState want) {
        return matches(actual, want, IGNORE_PLACE) && !matches(actual, want, IGNORE_FINAL);
    }

    public static String id(BlockState s) {
        return BuiltInRegistries.BLOCK.getKey(s.getBlock()).toString();
    }
}
