package vn.autobuild;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/** Chọn/nạp block vào hotbar, đếm đồ, chọn dụng cụ đào. Rương/shulker làm ở bản sau. */
public final class InventoryManager {
    private InventoryManager() {}

    private static int rotate = 0;
    private static Map<String, Item> itemsByName;

    /** "cooked_beef" hoặc "minecraft:cooked_beef" -> Item, không thấy thì null. */
    public static synchronized Item itemByName(String name) {
        if (itemsByName == null) {
            itemsByName = new HashMap<>();
            for (Item it : BuiltInRegistries.ITEM) itemsByName.put(BuiltInRegistries.ITEM.getKey(it).toString(), it);
        }
        if (name == null) return null;
        return itemsByName.get(name.contains(":") ? name : "minecraft:" + name);
    }

    public static int count(LocalPlayer p, Item item) {
        int n = 0;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    /** Số ô trống trong túi chính + hotbar (36 ô). */
    public static int freeSlots(LocalPlayer p) {
        int n = 0;
        Inventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) if (inv.getItem(i).isEmpty()) n++;
        return n;
    }

    /** true = đang cầm đúng item trên tay chính. false = chưa (hết đồ, hoặc đang chờ server cập nhật hotbar). */
    public static boolean equip(Minecraft mc, Item item) {
        LocalPlayer p = mc.player;
        Inventory inv = p.getInventory();
        if (p.getMainHandItem().is(item)) return true;

        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).is(item)) { inv.setSelectedSlot(i); return true; }
        }
        // Có trong túi chính: hoán đổi vào hotbar (chờ tick sau để server cập nhật)
        for (int i = 9; i < 36; i++) {
            if (inv.getItem(i).is(item)) {
                int hb = freeHotbarSlot(inv);
                mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, i, hb, ClickType.SWAP, p);
                inv.setSelectedSlot(hb);
                return false;
            }
        }
        // Creative: tự "lấy" item
        if (p.getAbilities().instabuild) {
            int hb = freeHotbarSlot(inv);
            ItemStack st = item.getDefaultInstance();
            inv.setItem(hb, st);
            mc.gameMode.handleCreativeModeItemAdd(st, 36 + hb);
            inv.setSelectedSlot(hb);
            return true;
        }
        return false;
    }

    /** Sinh tồn: chọn trong hotbar dụng cụ đào nhanh nhất cho block này (không đụng túi chính). */
    public static void equipBestTool(Minecraft mc, BlockState state) {
        Inventory inv = mc.player.getInventory();
        int bestSlot = -1;
        float best = 1.0f;
        for (int i = 0; i < 9; i++) {
            float sp = inv.getItem(i).getDestroySpeed(state);
            if (sp > best) { best = sp; bestSlot = i; }
        }
        if (bestSlot >= 0) inv.setSelectedSlot(bestSlot);
    }

    /** Ưu tiên ô trống; không có thì ô không phải dụng cụ (có độ bền), để khỏi đẩy cúp/xẻng/kiếm ra khỏi hotbar. */
    private static int freeHotbarSlot(Inventory inv) {
        for (int i = 0; i < 9; i++) if (inv.getItem(i).isEmpty()) return i;
        for (int k = 0; k < 9; k++) {
            rotate = (rotate + 1) % 9;
            if (!inv.getItem(rotate).isDamageableItem()) return rotate;
        }
        rotate = (rotate + 1) % 9;
        return rotate;
    }
}
