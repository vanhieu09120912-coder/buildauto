package vn.autobuild;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

/** Tiện ích đọc/click GUI rương do server mở (như /ah). */
public final class Gui {
    private Gui() {}

    /** Menu của GUI server đang mở, hoặc null nếu chỉ có túi đồ thường. */
    public static AbstractContainerMenu menu(LocalPlayer p) {
        return p.containerMenu != p.inventoryMenu ? p.containerMenu : null;
    }

    public static String title(Minecraft mc) {
        return mc.screen == null ? "" : mc.screen.getTitle().getString();
    }

    /** Số slot của phần GUI phía trên (không tính 36 ô túi đồ người chơi ở dưới). */
    public static int top(AbstractContainerMenu m) {
        return Math.max(0, m.slots.size() - 36);
    }

    public static String itemId(ItemStack s) {
        return BuiltInRegistries.ITEM.getKey(s.getItem()).toString();
    }

    public static String name(ItemStack s) {
        return s.getHoverName().getString();
    }

    public static List<String> lore(ItemStack s) {
        List<String> out = new ArrayList<>();
        ItemLore l = s.get(DataComponents.LORE);
        if (l != null) for (Component c : l.lines()) out.add(c.getString());
        return out;
    }

    /** Dấu vân tay nội dung GUI: đổi trang / đổi listing thì chuỗi này đổi. */
    public static String fingerprint(AbstractContainerMenu m) {
        StringBuilder sb = new StringBuilder().append(m.containerId).append('#');
        int top = top(m);
        for (int i = 0; i < top; i++) {
            ItemStack s = m.slots.get(i).getItem();
            if (s.isEmpty()) { sb.append('.'); continue; }
            sb.append(itemId(s)).append('x').append(s.getCount()).append(name(s)).append(lore(s)).append(';');
        }
        return sb.toString();
    }

    public static void click(Minecraft mc, LocalPlayer p, AbstractContainerMenu m, int slot) {
        mc.gameMode.handleInventoryMouseClick(m.containerId, slot, 0, ClickType.PICKUP, p);
    }
}
