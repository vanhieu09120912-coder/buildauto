package vn.autobuild;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import vn.autobuild.BuildPlanner.Layer;
import vn.autobuild.BuildPlanner.Target;

/**
 * Bộ điều khiển chính: chạy mỗi tick, xây từng layer từ dưới lên.
 * Hai chế độ di chuyển: BAY (creative, như giai đoạn 1) và ĐI BỘ (sinh tồn: A* + nhảy + tháp).
 * Thiếu vật liệu thì chuyển sang trạng thái BUYING (AuctionBuyer) rồi quay lại xây.
 */
public final class BuildController {
    public enum State { IDLE, BUILDING, PAUSED, BUYING, CLEANUP, DONE }

    public static final BuildController I = new BuildController();

    public SchematicData raw;
    public String fileName = "";
    public BlockPos anchor;          // góc có X,Y,Z nhỏ nhất của công trình trong thế giới
    public int rotDeg = 0;
    public Mirror mirror = Mirror.NONE;
    public BuildPlanner planner;
    public State state = State.IDLE;
    public String note = "";
    /** Tiền đã chi trên /ah trong lần xây này. */
    public double spent;

    private int layerIdx, progressCounter, lastCounter, stuckCount, restockedLayer = -1, planFails, breakTicks, cleanTicks;
    private long tickNo, lastProgress, lastPlan, lastBuyTick = -100_000;
    /** Tick sớm nhất được đặt đợt kế tiếp (nhịp đặt chậm + ngẫu nhiên ở sinh tồn). */
    private long nextPlaceTick, lastHintTick = -100_000, lastBridgeTick = -100_000;
    private int bridgeTries;
    private final PathMover mover = new PathMover();
    private final Walker walker = new Walker();
    private final List<BlockPos> scaffolds = new ArrayList<>();
    private BlockPos breakTarget, planGoal;
    private Item lastBuyItem;
    private AuctionBuyer buyer;
    private State stateAfterBuy = State.IDLE;

    // ---------------------------------------------------------------- điều khiển

    public void load(Path file) throws IOException {
        raw = SchematicLoader.load(file);
        fileName = file.getFileName().toString();
        planner = null;
        state = State.IDLE;
        note = "";
    }

    public Rotation rotation() {
        return switch (rotDeg) {
            case 90 -> Rotation.CLOCKWISE_90;
            case 180 -> Rotation.CLOCKWISE_180;
            case 270 -> Rotation.COUNTERCLOCKWISE_90;
            default -> Rotation.NONE;
        };
    }

    /** @return null nếu bắt đầu được, ngược lại là thông báo lỗi. */
    public String start() {
        if (raw == null) return "Chưa load schematic. Dùng: /autobuild load <tên file>";
        if (anchor == null) return "Chưa đặt gốc. Đứng ở góc thấp nhất rồi gõ: /autobuild anchor";
        SchematicData t = SchematicLoader.transform(raw, rotation(), mirror);
        planner = new BuildPlanner(t, anchor);
        layerIdx = 0; tickNo = 0; lastProgress = 0; stuckCount = 0; progressCounter = 0; lastCounter = 0;
        nextPlaceTick = 0; lastHintTick = -100_000; lastBridgeTick = -100_000; bridgeTries = 0;
        restockedLayer = -1; planFails = 0; spent = 0; breakTarget = null; planGoal = null;
        scaffolds.clear();
        stopMoving();
        walker.towerCells.clear();
        state = State.BUILDING;
        note = "";
        return null;
    }

    public void pause(String why) {
        if (state != State.BUILDING) return;
        state = State.PAUSED;
        note = why;
        stopMoving();
        Survival.reset(Minecraft.getInstance());
        msg("§e[AutoBuild] Tạm dừng: " + why);
    }

    public String resume() {
        if (planner == null) return "Chưa start.";
        if (state != State.PAUSED) return "Không đang tạm dừng.";
        state = State.BUILDING;
        note = "";
        lastProgress = tickNo;
        planFails = 0;
        return null;
    }

    public void stop() {
        Minecraft mc = Minecraft.getInstance();
        if (buyer != null) { buyer.abort(mc); buyer = null; }
        state = State.IDLE;
        note = "";
        breakTarget = null;
        stopMoving();
        Survival.reset(mc);
    }

    public String gotoLayer(int n) {
        if (planner == null) return "Chưa start.";
        if (n < 1 || n > planner.layers.size()) return "Layer phải từ 1 đến " + planner.layers.size();
        layerIdx = n - 1;
        planner.layers.get(layerIdx).synced = false;
        restockedLayer = -1;
        stopMoving();
        return null;
    }

    /** Dọn các cột tháp đã dựng (nhảy-đặt). */
    public String cleanup() {
        if (walker.towerCells.isEmpty()) return "Không có giàn tháp nào cần dọn.";
        if (state == State.BUILDING || state == State.BUYING) return "Hãy /autobuild pause hoặc stop trước.";
        state = State.CLEANUP;
        cleanTicks = 0;
        return null;
    }

    /** Mua tay một món để thử module /ah (lệnh /ab ah buy). */
    public String manualBuy(Item item, int count) {
        if (state == State.BUYING || state == State.CLEANUP) return "Đang bận: " + state;
        if (!Config.INSTANCE.ah.enabled) return "ah.enabled đang là false trong config.json";
        stateAfterBuy = state == State.BUILDING ? State.PAUSED : state;
        buyer = new AuctionBuyer(Map.of(item, count));
        state = State.BUYING;
        stopMoving();
        return null;
    }

    public String statusText() {
        String money = spent > 0 ? " | đã chi " + spent : "";
        if (planner == null) return "Trạng thái: " + state + (raw != null ? " | đã load " + fileName : " | chưa load");
        return "Trạng thái: " + state + " | Tầng " + Math.min(layerIdx + 1, planner.layers.size()) + "/" + planner.layers.size()
            + " | " + planner.done + "/" + planner.total + money + (note.isEmpty() ? "" : " | " + note);
    }

    private void stopMoving() {
        mover.clear();
        walker.abort(Minecraft.getInstance());
    }

    // ---------------------------------------------------------------- vòng lặp mỗi tick

    public void tick(Minecraft mc) {
        AhDump.tick(mc);
        if (state == State.BUYING) { tickBuying(mc); return; }
        if (state == State.CLEANUP) { tickCleanup(mc); return; }
        if (state != State.BUILDING || planner == null) return;

        LocalPlayer p = mc.player;
        ClientLevel lv = mc.level;
        if (p == null || lv == null || mc.gameMode == null) { state = State.PAUSED; note = "mất kết nối"; return; }
        Config cfg = Config.INSTANCE;
        if (!p.isAlive()) { pause("nhân vật đã chết"); return; }
        if (p.getHealth() < cfg.minHealth) { pause("máu thấp"); return; }
        if (mc.screen != null) { walker.release(mc); return; }          // đang mở chat/GUI: đứng yên
        boolean fly = p.getAbilities().mayfly && !cfg.forceWalk;
        if (!fly && p.getAbilities().flying) {                          // đi bộ thì phải xuống đất
            p.getAbilities().flying = false;
            p.onUpdateAbilities();
        }
        if (!fly && Survival.tick(mc, cfg)) { walker.release(mc); return; }   // đang ăn / đói
        if (state != State.BUILDING) return;                            // Survival có thể vừa pause
        tickNo++;

        if (layerIdx >= planner.layers.size()) { finish(); return; }
        Layer L = planner.layers.get(layerIdx);
        if (!L.synced) { sync(lv, L); L.synced = true; }

        // ---- đầu layer: thiếu vật liệu thì đi mua trước (chỉ sinh tồn)
        if (!p.getAbilities().instabuild && restockedLayer != layerIdx) {
            restockedLayer = layerIdx;
            if (Materials.urgent(p, planner, layerIdx)) {
                Map<Item, Integer> sh = Materials.shortfall(p, planner, layerIdx, cfg.ah.buyAheadLayers, cfg);
                if (startBuying(sh, "đầu layer #" + (layerIdx + 1))) return;
            }
        }

        verify(mc, L);
        cleanupScaffolds(mc);

        if (L.queue.isEmpty() && L.pending.isEmpty() && breakTarget == null) { endOfLayer(L); return; }

        Vec3 eye = p.getEyePosition();
        int pendMin = Integer.MAX_VALUE;
        for (Target t : L.pending) pendMin = Math.min(pendMin, t.phase);

        // ---- sinh tồn: đang đào dở một block (phải giữ nguyên dụng cụ trên tay cho tới khi vỡ)
        if (breakTarget != null) {
            BlockState bs = lv.getBlockState(breakTarget);
            if (bs.canBeReplaced() || eye.distanceTo(breakTarget.getCenter()) > cfg.reach || ++breakTicks > 200) {
                breakTarget = null;
            } else {
                walker.release(mc);
                InventoryManager.equipBestTool(mc, bs);
                Placer.breakBlock(mc, breakTarget);
                progressCounter++;
                return;
            }
        }

        // ---- đặt block trong tầm với
        int placed = 0, scanned = 0;
        List<Target> toBack = new ArrayList<>();
        boolean creative = p.getAbilities().instabuild;
        // Sinh tồn: mỗi lần đặt xong phải nghỉ N tick + ngẫu nhiên 0..J tick (xem Config.survival*) để server khó bắt
        boolean canPlace = tickNo >= nextPlaceTick;
        int perTick = cfg.blocksPerTickFor(creative);
        Iterator<Target> it = L.queue.iterator();
        while (canPlace && it.hasNext() && placed < perTick && scanned < 96) {
            Target t = it.next();
            scanned++;
            if (t.phase > pendMin) break;                         // chờ pha trước kiểm tra xong
            if (eye.distanceTo(t.pos.getCenter()) > cfg.reach) continue;
            if (p.getBoundingBox().intersects(new AABB(t.pos))) continue;   // đang đứng đè lên ô này

            BlockState cur = lv.getBlockState(t.pos);
            if (StateUtil.matches(cur, t.want, StateUtil.IGNORE_FINAL)) {   // đã có sẵn đúng
                t.done = true; L.done++; planner.done++; progressCounter++; it.remove();
                continue;
            }
            if (!cur.canBeReplaced()) {                           // đang có block sai -> phá
                if (creative) {
                    Placer.breakBlock(mc, t.pos);
                    if (++t.noPlanTicks > 100) { it.remove(); fail(L, t, "ô bị block khác chiếm, không phá được"); }
                } else {
                    breakTarget = t.pos; breakTicks = 0;           // sinh tồn: đào riêng ở các tick sau
                    break;
                }
                continue;
            }
            if (!InventoryManager.equip(mc, t.item)) {
                if (!creative && InventoryManager.count(p, t.item) == 0) {
                    Map<Item, Integer> sh = Materials.shortfall(p, planner, layerIdx, cfg.ah.buyAheadLayers, cfg);
                    sh.putIfAbsent(t.item, 1);
                    boolean again = lastBuyItem == t.item && tickNo - lastBuyTick < 400;   // vừa mua mà vẫn thiếu
                    lastBuyItem = t.item;
                    if (!again && startBuying(sh, "hết " + BuiltInRegistries.ITEM.getKey(t.item))) return;
                    pause("hết " + BuiltInRegistries.ITEM.getKey(t.item) + " - bỏ thêm vào túi rồi /autobuild resume"
                        + (cfg.ah.enabled ? " (mua /ah chưa thành công)" : " (bật ah.enabled để tự mua)"));
                    return;
                }
                continue; // đang chờ hotbar cập nhật
            }
            PlacementSolver.Plan plan = PlacementSolver.solve(mc, t.pos, t.want, eye, cfg);
            if (plan == null) {
                if (cfg.useScaffold && t.scaffoldTries < 3 && tryScaffold(mc, t, eye)) { t.scaffoldTries++; placed++; continue; }
                if (++t.noPlanTicks > 40) {
                    t.noPlanTicks = 0;
                    it.remove();
                    if (++t.retries > cfg.maxRetries) fail(L, t, "không có mặt tựa / không đặt đúng hướng được");
                    else { t.order += 100_000_000; toBack.add(t); }
                }
                continue;
            }
            if (Placer.place(mc, plan)) {
                t.placedAt = tickNo;
                it.remove();
                L.pending.add(t);
                placed++;
                progressCounter++;
            }
        }
        if (!toBack.isEmpty()) { L.queue.addAll(toBack); L.queue.sort(BuildPlanner.ORDER); }
        if (placed > 0) scheduleNextPlace(cfg, creative);

        // ---- di chuyển
        if (fly) moveFly(lv, L, pendMin, eye, cfg, p, mc);
        else moveWalk(mc, L, pendMin, eye, cfg);

        // ---- kẹt thì lập lại kế hoạch
        if (progressCounter != lastCounter) {
            lastCounter = progressCounter;
            lastProgress = tickNo;
        } else if (tickNo - lastProgress > cfg.stuckSeconds * 20L) {
            lastProgress = tickNo;
            stuckCount++;
            stopMoving();
            planGoal = null;
            if (!L.queue.isEmpty()) {
                Target f = L.queue.remove(0);
                f.order += 100_000_000;
                if (stuckCount > 6) fail(L, f, "kẹt, không tiến triển được");
                else L.queue.add(f);
                L.queue.sort(BuildPlanner.ORDER);
            }
            msg("§c[AutoBuild] Kẹt, lập lại kế hoạch (lần " + stuckCount + ")");
            if (stuckCount > 20) { pause("kẹt quá lâu"); return; }
        }

        if (tickNo % 5 == 0) p.displayClientMessage(Component.literal(hud(L, p)), true);
    }

    // ---------------------------------------------------------------- di chuyển

    private void moveFly(ClientLevel lv, Layer L, int pendMin, Vec3 eye, Config cfg, LocalPlayer p, Minecraft mc) {
        if (!L.queue.isEmpty()) {
            Target front = L.queue.get(0);
            if (front.phase <= pendMin) {
                if (eye.distanceTo(front.pos.getCenter()) > cfg.reach - 0.3) {
                    mover.setGoal(PathMover.hoverPoint(lv, front.pos, cfg.hoverHeight));
                } else {
                    mover.clear();
                }
            }
        }
        mover.tick(mc, cfg);
    }

    /** Có thể đặt ô này từ chỗ đang đứng không (trong tầm, không đè lên người, solver đã tìm được cách). */
    private boolean canReach(LocalPlayer p, Target t, Vec3 eye, Config cfg) {
        return eye.distanceTo(t.pos.getCenter()) <= cfg.reach - 0.3
            && !p.getBoundingBox().intersects(new AABB(t.pos))
            && t.noPlanTicks < 10;
    }

    private void moveWalk(Minecraft mc, Layer L, int pendMin, Vec3 eye, Config cfg) {
        LocalPlayer p = mc.player;
        if (walker.isTowering()) {
            // Dừng tháp khi chân đã gần ngang ô cần đặt
            if (!L.queue.isEmpty() && p.onGround() && p.blockPosition().getY() >= L.queue.get(0).pos.getY() - 1) {
                walker.stopTower(mc);
                planGoal = null;
            } else {
                walker.towerTick(mc, cfg);
                progressCounter++;                       // đang leo = đang tiến triển
                return;
            }
        }
        if (L.queue.isEmpty()) { walker.clear(mc); return; }
        Target front = L.queue.get(0);
        if (front.phase > pendMin) { walker.clear(mc); return; }       // chờ kiểm tra pha trước
        if (canReach(p, front, eye, cfg)) { walker.clear(mc); planFails = 0; planGoal = null; return; }

        boolean following = walker.hasPath() && !walker.hasFailed() && !walker.isFinished();
        if (following && front.pos.equals(planGoal)) { walker.tick(mc, cfg); return; }
        if (tickNo - lastPlan < 8 && !walker.hasFailed()) { walker.tick(mc, cfg); return; }   // chống tìm đường dồn dập
        lastPlan = tickNo;
        planGoal = front.pos;
        List<BlockPos> path = StandFinder.pathTo(mc, front.pos, front.want, cfg);
        if (path != null) { walker.follow(path); planFails = 0; walker.tick(mc, cfg); return; }

        // Không có đường tới chỗ đứng nào => tự dựng giàn bằng block giàn (scaffoldBlock):
        //  - ô cao hơn chân từ 2 block: dựng THÁP (nhảy + đặt dưới chân) ở cột sát công trình nhất, chưa đủ cao thì dựng tiếp;
        //  - ô ngang tầm hoặc thấp hơn mà không có chỗ đứng: BẮC CẦU ngang từng ô về phía ô cần đặt.
        // Hai việc nối nhau: tháp đưa lên độ cao, cầu đưa sang chỗ cần. Giàn được ghi nhớ và dọn ở cuối (/ab cleanup).
        walker.clear(mc);
        BlockPos feet = p.blockPosition();
        int up = front.pos.getY() - feet.getY();
        String why = "không có chỗ đứng / không đi tới được";
        if (cfg.useScaffold) {
            Block sb = SchematicLoader.blockByName(cfg.scaffoldBlock);
            boolean creative = p.getAbilities().instabuild;
            if (sb == null) {
                why += " (scaffoldBlock sai tên: " + cfg.scaffoldBlock + ")";
            } else if (walker.towerCells.size() >= cfg.towerTotalMax) {
                why += " (đã dựng " + walker.towerCells.size() + " ô giàn, chạm towerTotalMax)";
            } else if (up >= 2) {
                if (!creative && InventoryManager.count(p, sb.asItem()) < 2) {
                    if (restockScaffold(sb, Math.max(cfg.minScaffold, up + 2),
                            "§e[AutoBuild] Ô cần đặt cao hơn chân " + up + " block, cần " + cfg.scaffoldBlock
                            + " để dựng tháp lên. Bỏ thêm vào túi (hoặc bật ah.enabled).")) return;
                    why += " (ô cao hơn chân " + up + " block mà hết " + cfg.scaffoldBlock + " để dựng tháp)";
                } else {
                    boolean onTower = walker.towerCells.contains(feet.below());       // đang đứng trên giàn: dựng tiếp tại chỗ
                    BlockPos spot = onTower ? feet : findTowerSpot(mc.level, feet, front.pos);
                    if (spot != null && spot.equals(feet)) {
                        if (columnFree(mc.level, feet, front.pos.getY())) {
                            walker.startTower(Math.min(cfg.towerMax, up + 1));
                            return;
                        }
                    } else if (spot != null) {                                       // đi tới chân cột rồi mới dựng
                        List<BlockPos> toSpot = Pathfinder.find(mc.level, feet, Set.of(spot.asLong()), front.pos, cfg.maxPathNodes);
                        if (toSpot != null) { walker.follow(toSpot); walker.tick(mc, cfg); return; }
                    }
                    why += " (ô cao hơn chân " + up + " block, không tìm được cột trống để dựng tháp)";
                }
            } else if (cfg.useBridge) {
                if (bridgeStep(mc, front, sb, cfg)) return;
                why += " (không bắc cầu tới được)";
            }
        }
        // Đẩy ô này ra sau, thử ô khác trước
        L.queue.remove(0);
        front.order += 100_000_000;
        if (++front.retries > cfg.maxRetries) fail(L, front, why);
        else L.queue.add(front);
        L.queue.sort(BuildPlanner.ORDER);
        planGoal = null;
    }

    private void scheduleNextPlace(Config cfg, boolean creative) {
        int jitter = cfg.placeJitterFor(creative);
        nextPlaceTick = tickNo + cfg.placeIntervalFor(creative) + (jitter > 0 ? ThreadLocalRandom.current().nextInt(jitter + 1) : 0);
    }

    /** Hết block giàn: tự mua trên /ah (nếu bật) hoặc báo người chơi. @return true nếu đã chuyển sang BUYING. */
    private boolean restockScaffold(Block sb, int want, String hintText) {
        boolean again = lastBuyItem == sb.asItem() && tickNo - lastBuyTick < 400;     // vừa mua mà vẫn thiếu thì thôi
        if (!again) {
            lastBuyItem = sb.asItem();
            if (startBuying(Map.of(sb.asItem(), want), "hết block giàn")) return true;
        }
        hint(hintText);
        return false;
    }

    /**
     * Bắc cầu MỘT bước về phía ô cần đặt. Mỗi lượt gọi làm đúng một việc:
     * ô phía trước đã đứng được thì bước lên; chưa có sàn thì kê một block giàn vào mặt bên của block đang đứng.
     * Chỉ đi theo trục làm GIẢM khoảng cách ngang tới ô cần đặt nên không thể đi lan man vô hạn.
     * @return true = đã làm gì đó / đang đợi (không báo lỗi ô này); false = không bắc cầu được.
     */
    private boolean bridgeStep(Minecraft mc, Target front, Block sb, Config cfg) {
        LocalPlayer p = mc.player;
        ClientLevel lv = mc.level;
        BlockPos feet = p.blockPosition();
        if (!Pathfinder.standable(lv, feet)) return false;              // phải đang đứng vững trên block đặc nguyên khối
        if (!p.onGround()) return true;                                 // đang rơi/nhảy: đợi chạm đất
        int dx = front.pos.getX() - feet.getX(), dz = front.pos.getZ() - feet.getZ();
        Direction dirX = dx > 0 ? Direction.EAST : Direction.WEST;
        Direction dirZ = dz > 0 ? Direction.SOUTH : Direction.NORTH;
        Direction[] order = Math.abs(dx) >= Math.abs(dz) ? new Direction[] {dirX, dirZ} : new Direction[] {dirZ, dirX};
        for (Direction d : order) {
            if ((d.getStepX() != 0 ? dx : dz) == 0) continue;           // trục này đã thẳng hàng với ô cần đặt
            BlockPos n = feet.relative(d);                              // ô chân sẽ bước tới
            BlockPos m = n.below();                                     // ô sàn của nó
            if (!Pathfinder.passable(lv, n) || !Pathfinder.passable(lv, n.above())) continue;
            if (Pathfinder.standable(lv, n)) {                          // đã có sàn: bước lên
                bridgeTries = 0;
                lastBridgeTick = tickNo;
                progressCounter++;
                walker.follow(List.of(feet, n));
                walker.tick(mc, cfg);
                return true;
            }
            BlockState ms = lv.getBlockState(m);
            if (!ms.canBeReplaced() || !ms.getFluidState().isEmpty()) continue;   // sàn đang là thứ khác (slab, nước...): không kê được
            if (planner.wants(m)) continue;                             // ô này công trình cần, không kê giàn vào
            if (bridgeTries >= 6) { bridgeTries = 0; return false; }    // đặt mãi không lên (server từ chối?)
            boolean creative = p.getAbilities().instabuild;
            if (!creative && InventoryManager.count(p, sb.asItem()) < 1) {
                return restockScaffold(sb, cfg.minScaffold, "§e[AutoBuild] Cần bắc cầu tới ô " + front.pos.toShortString()
                    + " nhưng hết " + cfg.scaffoldBlock + ". Bỏ thêm vào túi (hoặc bật ah.enabled).");
            }
            if (!InventoryManager.equip(mc, sb.asItem())) return true;  // đang chờ hoán đổi hotbar
            if (tickNo < nextPlaceTick) return true;                    // giữ nhịp đặt chậm của sinh tồn
            BlockPos floor = feet.below();                              // block đang đứng
            Vec3 loc = floor.getCenter().add(d.getStepX() * 0.5, 0.45, d.getStepZ() * 0.5);   // mặt bên, sát mép trên
            float[] look = PlacementSolver.lookAt(p.getEyePosition(), loc);
            if (Placer.placeRaw(mc, new BlockHitResult(loc, d, floor, false), look[0], look[1])) {
                walker.towerCells.add(m);                               // nhớ để dọn ở cuối
                bridgeTries++;
                lastBridgeTick = tickNo;
                progressCounter++;
                scheduleNextPlace(cfg, creative);
                return true;
            }
        }
        return false;
    }

    /** Cột từ chân tới độ cao topY dựng tháp được: không đè lên ô công trình cần, phía trên không bị trần/block chặn. */
    private boolean columnFree(ClientLevel lv, BlockPos feet, int topY) {
        for (int y = feet.getY(); y <= topY; y++) {
            BlockPos c = new BlockPos(feet.getX(), y, feet.getZ());
            if (planner.wants(c)) return false;
            if (y >= feet.getY() + 2 && !Pathfinder.passable(lv, c)) return false;
        }
        return true;
    }

    /**
     * Chọn cột dựng tháp: ô đứng được trong bán kính 8 quanh người, cột trống, và GẦN Ô CẦN ĐẶT NHẤT theo mặt phẳng ngang
     * (tức là sát công trình nhất) để lên tới nơi thì bước sang công trình được. Bản 0.2.0 dựng ngay tại chỗ đang đứng,
     * nếu chỗ đó cách công trình vài block thì lên cao xong vẫn không có đường sang.
     */
    private BlockPos findTowerSpot(ClientLevel lv, BlockPos me, BlockPos target) {
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                for (int dy = -3; dy <= 2; dy++) {
                    BlockPos s = me.offset(dx, dy, dz);
                    int hx = s.getX() - target.getX(), hz = s.getZ() - target.getZ();
                    double score = hx * hx + hz * hz + 0.001 * s.distSqr(me);
                    if (score >= bestScore) continue;                 // đã có ô tốt hơn: khỏi kiểm tra tốn kém
                    if (!Pathfinder.standable(lv, s) || !columnFree(lv, s, target.getY())) continue;
                    best = s;
                    bestScore = score;
                }
            }
        }
        return best;
    }

    /** Báo người chơi nhưng không quá 1 lần mỗi 10 giây. */
    private void hint(String s) {
        if (tickNo - lastHintTick < 200) return;
        lastHintTick = tickNo;
        msg(s);
    }

    // ---------------------------------------------------------------- mua /ah

    /** @return true nếu đã chuyển sang trạng thái BUYING. */
    private boolean startBuying(Map<Item, Integer> shortage, String why) {
        Config cfg = Config.INSTANCE;
        if (!cfg.ah.enabled || shortage.isEmpty()) return false;
        buyer = new AuctionBuyer(shortage);
        stateAfterBuy = State.BUILDING;
        lastBuyTick = tickNo;
        state = State.BUYING;
        stopMoving();
        msg("§e[AutoBuild] Đi mua trên /ah (" + why + "): " + shortage.size() + " loại");
        return true;
    }

    private void tickBuying(Minecraft mc) {
        if (buyer == null) { state = stateAfterBuy; return; }
        AuctionBuyer.Result r = buyer.tick(mc);
        if (r == AuctionBuyer.Result.RUNNING) {
            if (mc.player != null && mc.player.getHealth() < Config.INSTANCE.minHealth) {   // đang mua mà bị đánh
                buyer.abort(mc);
                finishBuy(false, "máu thấp");
            }
            return;
        }
        if (r == AuctionBuyer.Result.DONE) finishBuy(true, "");
        else finishBuy(false, buyer.failReason);
    }

    private void finishBuy(boolean ok, String why) {
        spent += buyer.spent;
        buyer = null;
        if (ok) {
            state = stateAfterBuy;
            lastProgress = tickNo;
            msg("§a[AutoBuild] Mua xong, quay lại xây. Đã chi " + spent);
        } else {
            state = stateAfterBuy == State.BUILDING ? State.PAUSED : stateAfterBuy;
            note = "mua /ah thất bại: " + why;
            msg("§c[AutoBuild] Mua /ah thất bại: " + why + ". Dừng. Xử lý xong gõ /autobuild resume");
        }
    }

    // ---------------------------------------------------------------- dọn giàn tháp

    private void tickCleanup(Minecraft mc) {
        LocalPlayer p = mc.player;
        ClientLevel lv = mc.level;
        Config cfg = Config.INSTANCE;
        if (p == null || lv == null) { state = State.PAUSED; return; }
        if (mc.screen != null) { walker.release(mc); return; }
        List<BlockPos> tc = walker.towerCells;
        if (tc.isEmpty()) {
            walker.abort(mc);
            state = State.DONE;
            msg("§a[AutoBuild] Đã dọn xong giàn tháp.");
            return;
        }
        BlockPos top = tc.get(0);
        for (BlockPos c : tc) if (c.getY() > top.getY()) top = c;        // dọn từ trên xuống
        BlockState bs = lv.getBlockState(top);
        if (bs.isAir()) { tc.remove(top); cleanTicks = 0; return; }
        if (p.getEyePosition().distanceTo(top.getCenter()) <= cfg.reach - 0.3) {
            walker.release(mc);
            InventoryManager.equipBestTool(mc, bs);
            Placer.breakBlock(mc, top);                                  // đứng trên đỉnh thì đào block dưới chân rồi rơi xuống
            if (++cleanTicks > 300) { tc.remove(top); cleanTicks = 0; msg("§c[AutoBuild] Không dọn được một ô giàn, bỏ qua."); }
            return;
        }
        if (walker.hasPath() && !walker.hasFailed() && !walker.isFinished()) { walker.tick(mc, cfg); return; }
        List<BlockPos> path = StandFinder.pathTo(mc, top, null, cfg);
        if (path == null) { tc.remove(top); msg("§c[AutoBuild] Không đi tới được một ô giàn để dọn, bỏ qua."); return; }
        walker.follow(path);
    }

    // ---------------------------------------------------------------- các bước con

    /** Kiểm tra lại các ô đã đặt: đúng -> xong; chỉ lệch delay -> click chỉnh; sai -> phá và đặt lại. */
    private void verify(Minecraft mc, Layer L) {
        ClientLevel lv = mc.level;
        Config cfg = Config.INSTANCE;
        boolean slow = cfg.slowInSurvival && !mc.player.getAbilities().instabuild;
        int fixGap = slow ? Math.max(2, cfg.survivalPlaceIntervalTicks) : 2;   // sinh tồn: click chỉnh delay cũng chậm lại
        for (Iterator<Target> it = L.pending.iterator(); it.hasNext();) {
            Target t = it.next();
            BlockState cur = lv.getBlockState(t.pos);
            if (StateUtil.matches(cur, t.want, StateUtil.IGNORE_FINAL)) {
                t.done = true; L.done++; planner.done++; progressCounter++;
                it.remove();
                continue;
            }
            if (StateUtil.onlyClickFixDiffers(cur, t.want)) {
                if (t.fixClicks >= 8) { it.remove(); fail(L, t, "không chỉnh được delay/mode"); }
                else if (tickNo - t.lastFix >= fixGap) {
                    Placer.clickFix(mc, t.pos);
                    t.fixClicks++;
                    t.lastFix = tickNo;
                    progressCounter++;
                }
                continue;
            }
            if (tickNo - t.placedAt >= cfg.verifyDelayTicks) {
                it.remove();
                if (++t.retries > cfg.maxRetries) { fail(L, t, "blockstate sai sau nhiều lần đặt"); continue; }
                t.placedAt = -1;
                L.queue.add(t);          // vòng quét sau sẽ phá block sai (nếu có) rồi đặt lại
                L.queue.sort(BuildPlanner.ORDER);
            }
        }
    }

    private void sync(ClientLevel lv, Layer L) {
        for (Iterator<Target> it = L.queue.iterator(); it.hasNext();) {
            Target t = it.next();
            if (StateUtil.matches(lv.getBlockState(t.pos), t.want, StateUtil.IGNORE_FINAL)) {
                t.done = true; L.done++; planner.done++;
                it.remove();
            }
        }
    }

    /** Kê block tạm cạnh ô lơ lửng để có chỗ tựa (độ sâu 1). Dọn đi sau khi đặt xong. */
    private boolean tryScaffold(Minecraft mc, Target t, Vec3 eye) {
        Config cfg = Config.INSTANCE;
        Block sb = SchematicLoader.blockByName(cfg.scaffoldBlock);
        if (sb == null) return false;
        BlockState ss = sb.defaultBlockState();
        for (Direction d : Direction.values()) {
            BlockPos n = t.pos.relative(d);
            BlockState ns = mc.level.getBlockState(n);
            if (!ns.canBeReplaced() || !ns.getFluidState().isEmpty()) continue; // phải là ô trống
            if (planner.wants(n)) continue;                                     // không kê vào ô công trình cần
            if (eye.distanceTo(n.getCenter()) > cfg.reach) continue;
            if (!InventoryManager.equip(mc, sb.asItem())) return false;
            PlacementSolver.Plan sp = PlacementSolver.solve(mc, n, ss, eye, cfg);
            if (sp == null) continue;
            if (Placer.place(mc, sp)) { scaffolds.add(n); progressCounter++; return true; }
        }
        return false;
    }

    private void cleanupScaffolds(Minecraft mc) {
        boolean creative = mc.player.getAbilities().instabuild;
        for (Iterator<BlockPos> it = scaffolds.iterator(); it.hasNext();) {
            BlockPos s = it.next();
            if (mc.level.getBlockState(s).isAir()) { it.remove(); continue; }
            boolean needed = false;
            for (Direction d : Direction.values()) {
                Target t = planner.targetAt(s.relative(d));
                if (t != null && !t.done && !t.failed) { needed = true; break; }
            }
            if (needed) continue;
            if (creative) Placer.breakBlock(mc, s);
            else if (breakTarget == null) { breakTarget = s; breakTicks = 0; }   // sinh tồn: đào qua cơ chế breakTarget
        }
    }

    private void fail(Layer L, Target t, String why) {
        t.failed = true;
        t.failReason = why;
        L.failed.add(t);
        progressCounter++;
    }

    private void endOfLayer(Layer L) {
        // Các ô khó được xử lý lại một lượt ở cuối layer
        if (!L.failed.isEmpty() && !L.retried) {
            L.retried = true;
            for (Target t : L.failed) {
                t.failed = false; t.retries = 0; t.noPlanTicks = 0; t.scaffoldTries = 0; t.placedAt = -1;
                L.queue.add(t);
            }
            L.failed.clear();
            L.queue.sort(BuildPlanner.ORDER);
            msg("§e[AutoBuild] Xử lý lại các ô khó ở cuối layer #" + (layerIdx + 1));
            return;
        }
        int n = layerIdx + 1;
        if (!L.failed.isEmpty()) {
            Target f = L.failed.get(0);
            msg("§c[AutoBuild] Layer #" + n + " còn " + L.failed.size() + " ô không đặt được. Ví dụ "
                + f.pos.getX() + "," + f.pos.getY() + "," + f.pos.getZ() + ": " + f.failReason);
        }
        stopMoving();
        stuckCount = 0;
        planGoal = null;
        layerIdx++;
        if (layerIdx < planner.layers.size()) msg("§a[AutoBuild] Layer #" + n + " complete, advancing to Layer #" + (n + 1));
    }

    private void finish() {
        int failed = 0;
        for (Layer l : planner.layers) failed += l.failed.size();
        stopMoving();
        msg("§a[AutoBuild] Xong! " + planner.done + "/" + planner.total + " block"
            + (failed > 0 ? ", §c" + failed + " ô không đặt được" : "") + (spent > 0 ? ", đã chi " + spent : "") + ".");
        if (!walker.towerCells.isEmpty()) {
            msg("§e[AutoBuild] Dọn " + walker.towerCells.size() + " ô giàn tháp...");
            state = State.CLEANUP;
            cleanTicks = 0;
        } else {
            state = State.DONE;
        }
    }

    private String hud(Layer L, LocalPlayer p) {
        int pct = planner.total == 0 ? 100 : (int) (100L * planner.done / planner.total);
        boolean moving = walker.hasPath() && !walker.isFinished() || mover.hasGoal() && !mover.arrived(p);
        String st = walker.isTowering() ? "đang leo" : tickNo - lastBridgeTick < 20 ? "đang bắc cầu" : moving ? "đang đi" : breakTarget != null ? "đang đào" : "đang xây";
        return "Tầng " + (layerIdx + 1) + "/" + planner.layers.size() + " | " + planner.done + "/" + planner.total
            + " (" + pct + "%) | " + st + (spent > 0 ? " | chi " + spent : "");
    }

    static void msg(String s) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(s), false);
    }
}
