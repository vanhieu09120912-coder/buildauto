package vn.autobuild;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Điều khiển nhân vật đi bộ như người thật: bấm phím tiến/nhảy (KeyMapping), xoay đầu theo hướng đi.
 * Server thấy đúng các gói di chuyển bình thường, không có "bay" hay dịch chuyển.
 * Có thêm "tháp": nhảy + đặt block dưới chân để lên cao khi không có đường (block giàn dọn ở cuối bằng /ab cleanup).
 */
public final class Walker {
    private List<BlockPos> path;
    private int idx;
    private boolean failed, finished;
    private Vec3 lastPos = Vec3.ZERO;
    private int still, checkTick;

    private boolean towering;
    private int towerLeft;
    private BlockPos stepCell;
    /** Các ô giàn tháp đã dựng (để dọn). */
    public final List<BlockPos> towerCells = new ArrayList<>();

    // ------------------------------------------------------------------ đi theo đường

    public void follow(List<BlockPos> p) {
        path = p; idx = 0; failed = false; finished = p.isEmpty(); still = 0; checkTick = 0;
    }

    public boolean hasPath() { return path != null; }
    public boolean hasFailed() { return failed; }
    public boolean isFinished() { return finished; }

    /** Bỏ đường đang đi, thả phím. */
    public void clear(Minecraft mc) {
        path = null; failed = false; finished = false;
        release(mc);
    }

    /** Dừng hẳn mọi thứ (kể cả tháp). */
    public void abort(Minecraft mc) {
        clear(mc);
        towering = false; stepCell = null;
    }

    public void release(Minecraft mc) {
        if (mc == null || mc.options == null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keySprint.setDown(false);
    }

    public void tick(Minecraft mc, Config cfg) {
        LocalPlayer p = mc.player;
        ClientLevel lv = mc.level;
        if (p == null || lv == null || path == null || failed || finished) { release(mc); return; }

        BlockPos feet = p.blockPosition();
        for (int j = Math.min(path.size() - 1, idx + 2); j >= idx; j--) {   // cho phép "nhảy cóc" tối đa 2 node
            if (feet.equals(path.get(j))) { idx = j + 1; break; }
        }
        if (idx >= path.size()) { finished = true; release(mc); return; }
        BlockPos nx = path.get(idx);

        // --- phát hiện lạc đường / kẹt / thế giới đổi
        if (Math.abs(feet.getX() - nx.getX()) > 2 || Math.abs(feet.getZ() - nx.getZ()) > 2 || Math.abs(feet.getY() - nx.getY()) > 3) {
            failed = true; release(mc); return;
        }
        if (++checkTick % 10 == 0 && !Pathfinder.standable(lv, nx)) { failed = true; release(mc); return; }
        Vec3 pos = p.position();
        if (pos.distanceTo(lastPos) < 0.02) still++; else still = 0;
        lastPos = pos;
        if (still > 25) { failed = true; release(mc); return; }

        // --- quay mặt về node kế và bấm phím
        double dx = nx.getX() + 0.5 - p.getX(), dz = nx.getZ() + 0.5 - p.getZ();
        p.setYRot((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setXRot(15f);
        mc.options.keyUp.setDown(true);
        mc.options.keySprint.setDown(cfg.sprint && Math.hypot(dx, dz) > 2.0);
        boolean jump = p.onGround() && (nx.getY() > feet.getY() || p.horizontalCollision);
        mc.options.keyJump.setDown(jump);
    }

    // ------------------------------------------------------------------ tháp

    public boolean isTowering() { return towering; }

    public void startTower(int n) {
        path = null; failed = false; finished = false;
        towering = true; towerLeft = n; stepCell = null;
    }

    public void stopTower(Minecraft mc) {
        towering = false; stepCell = null;
        release(mc);
    }

    /** Mỗi tick: đứng trên mặt đất thì nhảy; khi đã nhảy đủ cao thì đặt block vào ô chân cũ (nhìn thẳng xuống). */
    public void towerTick(Minecraft mc, Config cfg) {
        LocalPlayer p = mc.player;
        ClientLevel lv = mc.level;
        mc.options.keyUp.setDown(false);
        mc.options.keySprint.setDown(false);
        Block sb = SchematicLoader.blockByName(cfg.scaffoldBlock);
        boolean creative = p.getAbilities().instabuild;
        if (sb == null || towerLeft <= 0 || (!creative && InventoryManager.count(p, sb.asItem()) == 0)) {
            stopTower(mc);
            return;
        }
        if (!InventoryManager.equip(mc, sb.asItem())) { mc.options.keyJump.setDown(false); return; }
        p.setXRot(90f);
        if (p.onGround()) {
            stepCell = p.blockPosition();
            mc.options.keyJump.setDown(true);
            return;
        }
        mc.options.keyJump.setDown(false);
        if (stepCell != null && p.getY() >= stepCell.getY() + 1.0 + cfg.towerMargin) {
            BlockPos base = stepCell.below();
            Vec3 loc = new Vec3(stepCell.getX() + 0.5, stepCell.getY(), stepCell.getZ() + 0.5);
            BlockHitResult hit = new BlockHitResult(loc, Direction.UP, base, false);
            if (lv.getBlockState(stepCell).canBeReplaced() && Placer.placeRaw(mc, hit, p.getYRot(), 90f)) {
                towerCells.add(stepCell);
                towerLeft--;
                stepCell = null;
            }
        }
    }
}
