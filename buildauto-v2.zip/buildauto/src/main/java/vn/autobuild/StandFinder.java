package vn.autobuild;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Chọn chỗ ĐỨNG để đặt/phá một ô, rồi tìm đường đi bộ tới đó.
 * Chỗ đứng hợp lệ: đứng được (Pathfinder.standable), không nằm đè lên ô cần đặt, mắt trong tầm với,
 * và (nếu biết blockstate cần đặt) PlacementSolver tìm được cách đặt đúng từ chính chỗ đó.
 */
public final class StandFinder {
    private StandFinder() {}

    /** @param want blockstate cần đặt, hoặc null nếu chỉ cần đứng gần (ví dụ để phá). @return null nếu không có đường. */
    public static List<BlockPos> pathTo(Minecraft mc, BlockPos target, BlockState want, Config cfg) {
        ClientLevel lv = mc.level;
        LocalPlayer p = mc.player;
        double eyeH = p.getEyeHeight();
        int r = (int) Math.ceil(cfg.reach);
        BlockPos me = p.blockPosition();
        Vec3 tc = target.getCenter();

        List<BlockPos> raw = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -r; dy <= 3; dy++) {
                    BlockPos s = target.offset(dx, dy, dz);
                    if (s.equals(target) || s.above().equals(target)) continue;   // không đứng đè lên ô cần đặt
                    Vec3 eye = new Vec3(s.getX() + 0.5, s.getY() + eyeH, s.getZ() + 0.5);
                    if (eye.distanceTo(tc) > cfg.reach - 0.4) continue;           // chừa biên vì đứng lệch tâm
                    if (!Pathfinder.standable(lv, s)) continue;
                    raw.add(s);
                }
            }
        }
        if (raw.isEmpty()) return null;
        raw.sort(Comparator.comparingDouble(s -> s.distSqr(me)));

        Set<Long> goals = new HashSet<>();
        int tested = 0;
        for (BlockPos s : raw) {
            if (goals.size() >= 10 || tested >= 40) break;
            tested++;
            if (want != null) {
                Vec3 eye = new Vec3(s.getX() + 0.5, s.getY() + eyeH, s.getZ() + 0.5);
                if (PlacementSolver.solve(mc, target, want, eye, cfg) == null) continue;
            }
            goals.add(s.asLong());
        }
        // Ô lơ lửng (chưa có mặt tựa): đứng gần rồi để phần kê giàn tạm lo
        if (goals.isEmpty() && want != null && cfg.useScaffold) {
            for (int i = 0; i < Math.min(8, raw.size()); i++) goals.add(raw.get(i).asLong());
        }
        if (goals.isEmpty()) return null;
        return Pathfinder.find(lv, me, goals, target, cfg.maxPathNodes);
    }
}
