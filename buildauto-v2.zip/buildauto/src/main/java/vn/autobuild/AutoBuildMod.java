package vn.autobuild;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

public class AutoBuildMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Config.load();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> BuildController.I.tick(mc));
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> Commands.register(dispatcher));
        // Ghi lại thông báo/chat từ server để module /ah đọc kết quả mua và để /ab ah watch ghi file
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> { if (!overlay) ChatLog.add(message.getString()); });
    }
}
