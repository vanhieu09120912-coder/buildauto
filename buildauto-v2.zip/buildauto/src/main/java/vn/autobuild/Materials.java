package vn.autobuild;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import vn.autobuild.BuildPlanner.Layer;
import vn.autobuild.BuildPlanner.Target;

/** Tính vật liệu còn cần so với túi đồ. */
public final class Materials {
    private Materials() {}

    /** Số block còn phải đặt (chưa đặt, không tính ô đang chờ kiểm tra) của các layer [from, toExcl). */
    public static Map<Item, Integer> needed(BuildPlanner pl, int from, int toExcl) {
        Map<Item, Integer> m = new LinkedHashMap<>();
        for (int i = Math.max(0, from); i < Math.min(toExcl, pl.layers.size()); i++) {
            Layer l = pl.layers.get(i);
            for (Target t : l.queue) m.merge(t.item, 1, Integer::sum);
        }
        return m;
    }

    /** Layer hiện tại có món nào thiếu so với túi không (dùng để quyết định có đi mua không). */
    public static boolean urgent(LocalPlayer p, BuildPlanner pl, int layer) {
        for (Map.Entry<Item, Integer> e : needed(pl, layer, layer + 1).entrySet()) {
            if (InventoryManager.count(p, e.getKey()) < e.getValue()) return true;
        }
        return false;
    }

    /**
     * Danh sách cần mua: thiếu bao nhiêu cho layer hiện tại + `ahead` layer kế, cộng block giàn (nếu bật),
     * rút gọn để không vượt số ô trống trong túi (chừa 2 ô).
     */
    public static Map<Item, Integer> shortfall(LocalPlayer p, BuildPlanner pl, int layer, int ahead, Config cfg) {
        Map<Item, Integer> need = needed(pl, layer, layer + 1 + Math.max(0, ahead));
        Map<Item, Integer> out = new LinkedHashMap<>();
        for (Map.Entry<Item, Integer> e : need.entrySet()) {
            int miss = e.getValue() - InventoryManager.count(p, e.getKey());
            if (miss > 0) out.put(e.getKey(), miss);
        }
        if (cfg.useScaffold) {
            Block sb = SchematicLoader.blockByName(cfg.scaffoldBlock);
            if (sb != null) {
                int miss = cfg.minScaffold - InventoryManager.count(p, sb.asItem());
                if (miss > 0) out.merge(sb.asItem(), miss, Integer::sum);
            }
        }
        int slots = Math.max(0, InventoryManager.freeSlots(p) - 2);
        Map<Item, Integer> capped = new LinkedHashMap<>();
        for (Map.Entry<Item, Integer> e : out.entrySet()) {
            int stack = Math.max(1, e.getKey().getDefaultMaxStackSize());
            int stacks = (e.getValue() + stack - 1) / stack;
            if (stacks > slots) stacks = slots;
            if (stacks <= 0) continue;
            slots -= stacks;
            capped.put(e.getKey(), Math.min(e.getValue(), stacks * stack));
        }
        return capped;
    }
}
