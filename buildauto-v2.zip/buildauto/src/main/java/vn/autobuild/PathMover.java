package vn.autobuild;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.phys.Vec3;

/**
 * Giai đoạn 1: chỉ có chế độ BAY (creative). Đi bộ có tìm đường (A*) + leo bằng giàn làm ở giai đoạn 1.5.
 */
public final class PathMover {
    private Vec3 goal;

    public void setGoal(Vec3 g) { goal = g; }
    public void clear() { goal = null; }
    public boolean hasGoal() { return goal != null; }

    public boolean arrived(LocalPlayer p) {
        return goal == null || p.position().distanceTo(goal) < 0.2;
    }

    public void tick(Minecraft mc, Config cfg) {
        LocalPlayer p = mc.player;
        if (goal == null || p == null) return;
        Abilities a = p.getAbilities();
        if (!a.flying) {
            a.flying = true;
            p.onUpdateAbilities(); // báo cho server biết đang bay
        }
        Vec3 d = goal.subtract(p.position());
        double dist = d.length();
        if (dist < 0.1) { p.setDeltaMovement(Vec3.ZERO); return; }
        p.setDeltaMovement(d.scale(Math.min(cfg.flySpeed, dist) / dist));
    }

    /** Điểm lơ lửng phía trên ô cần đặt, tự nâng lên nếu bị vướng block. */
    public static Vec3 hoverPoint(ClientLevel lv, BlockPos t, double h) {
        int y = t.getY() + (int) Math.ceil(h);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int i = 0; i < 16; i++) {
            m.set(t.getX(), y + i, t.getZ());
            boolean feet = lv.getBlockState(m).getCollisionShape(lv, m).isEmpty();
            m.set(t.getX(), y + i + 1, t.getZ());
            boolean head = lv.getBlockState(m).getCollisionShape(lv, m).isEmpty();
            if (feet && head) return new Vec3(t.getX() + 0.5, y + i, t.getZ() + 0.5);
        }
        return new Vec3(t.getX() + 0.5, y, t.getZ() + 0.5);
    }
}
