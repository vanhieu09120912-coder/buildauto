package vn.autobuild;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;

/** Những việc riêng của sinh tồn: tự ăn khi đói. */
public final class Survival {
    private Survival() {}

    private static boolean eating;

    /** @return true nếu đang bận (ăn hoặc vừa pause) -> controller bỏ qua phần xây ở tick này. */
    public static boolean tick(Minecraft mc, Config cfg) {
        LocalPlayer p = mc.player;
        if (p.getAbilities().instabuild) { eating = false; return false; }

        if (eating) {
            if (p.isUsingItem()) { mc.options.keyUse.setDown(true); return true; }  // giữ chuột phải tới khi ăn xong
            eating = false;
            mc.options.keyUse.setDown(false);
            return false;
        }
        if (p.getFoodData().getFoodLevel() >= cfg.minFood) return false;

        if (!cfg.autoEat) { BuildController.I.pause("đói (autoEat đang tắt)"); return true; }
        Item food = findFood(p, cfg);
        if (food == null) { BuildController.I.pause("đói và không có đồ ăn trong túi (xem config foodItems)"); return true; }
        if (!InventoryManager.equip(mc, food)) return true;                            // đang chờ hoán đổi hotbar
        InteractionResult r = mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
        if (r.consumesAction()) eating = true;
        return true;
    }

    public static void reset(Minecraft mc) {
        if (eating && mc != null && mc.options != null) mc.options.keyUse.setDown(false);
        eating = false;
    }

    private static Item findFood(LocalPlayer p, Config cfg) {
        for (String name : cfg.foodItems) {
            Item it = InventoryManager.itemByName(name);
            if (it != null && InventoryManager.count(p, it) > 0) return it;
        }
        return null;
    }
}
