# BuildAuto (Fabric, client-side) — Giai đoạn 1

Mod client tự đọc `.litematic` và tự đặt block theo từng layer. Không dùng Litematica/MaLiLib/Tweakeroo.

## Build ra .jar bằng GitHub Actions (Minecraft 1.21.11, Java 21)
Không cần cài Java/Gradle trên máy. Workflow nằm ở `.github/workflows/build.yml`.
1. Tạo repo mới tên `buildauto` trên GitHub, upload toàn bộ nội dung thư mục này lên (nhớ cả thư mục `.github`).
2. Vào tab **Actions** → chạy **Build** (tự chạy mỗi lần push, hoặc bấm *Run workflow*).
3. Khi xong (dấu tick xanh), mở lần chạy đó → mục **Artifacts** → tải `buildauto-jar` → giải nén ra `buildauto-0.1.0.jar`.
4. Bỏ jar + Fabric API vào thư mục `mods`.
Nếu Gradle báo không tìm thấy phiên bản, đối chiếu số trong `gradle.properties` với https://fabricmc.net/develop/template/ .

## Test (singleplayer, creative)
1. Bỏ file `.litematic` vào `.minecraft/config/autobuild/schematics/`.
2. Vào thế giới creative (superflat cho dễ). Gõ:
   - `/autobuild list` rồi `/autobuild load <tên>`
   - Đứng ở góc thấp nhất (X,Y,Z nhỏ nhất) nơi muốn xây: `/autobuild anchor`
   - (tuỳ chọn) `/autobuild rotate 90`, `/autobuild mirror x`, `/autobuild materials`
   - `/autobuild start` ... `pause` / `resume` / `stop` / `status` / `layer N`
3. Bot bay lơ lửng phía trên layer đang xây, đặt block trong tầm với.

## Config: `.minecraft/config/autobuild/config.json`
`reach`, `blocksPerTick`, `placeIntervalTicks` (tăng = chậm lại), `verifyDelayTicks`, `maxRetries`,
`hoverHeight`, `flySpeed`, `stuckSeconds`, `minHealth`, `requireRaycast`, `maxLookAngleDeg`,
`useScaffold`, `scaffoldBlock`. Sửa xong gõ `/autobuild reload`.

## Giai đoạn 1 CHƯA có (làm ở 1.5 / 2 / 3)
- Nước/lava bằng xô (đang bị bỏ qua và báo trong "Bỏ qua/tự sinh")
- Đi bộ có tìm đường (A*) và leo tầng bằng giàn — hiện cần creative/bay
- Slab đôi; chỉnh nội dung rương; .schem/.nbt
- Mua /ah (giai đoạn 2), HUD đẹp + outline + lưu tiến độ + phím tắt (giai đoạn 3)

## Cấu trúc
`NbtReader` + `PackedBits` (đọc file, đã test độc lập) · `SchematicLoader` (gộp region, xoay/lật) ·
`BuildPlanner` (layer, pha, thứ tự) · `PlacementSolver` (tìm hướng nhìn + mặt click để ra đúng blockstate) ·
`Placer` · `PathMover` · `InventoryManager` · `BuildController` (vòng lặp chính) · `Commands` · `Config`.
