package vn.autobuild;

import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.List;

/** Nhớ vài chục dòng chat/thông báo gần nhất từ server để module /ah đọc kết quả (mua được/không đủ tiền/...). */
public final class ChatLog {
    private ChatLog() {}

    private static final ArrayDeque<String> BUF = new ArrayDeque<>();
    private static long seq;

    public static synchronized void add(String s) {
        BUF.addLast(s);
        if (BUF.size() > 80) BUF.removeFirst();
        seq++;
    }

    /** Đánh dấu "bây giờ"; sau đó gọi since(mark) để lấy các dòng mới hơn. */
    public static synchronized long mark() { return seq; }

    public static synchronized List<String> since(long mark) {
        long n = Math.min(seq - mark, BUF.size());
        List<String> all = new ArrayList<>(BUF);
        return n <= 0 ? List.of() : all.subList(all.size() - (int) n, all.size());
    }
}
