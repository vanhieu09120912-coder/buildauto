package vn.autobuild;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;

/** Cấu hình lưu ở config/autobuild/config.json. Sửa file rồi gõ /autobuild reload (hoặc vào lại game). */
public final class Config {
    // ------------------------------------------------------------------ giai đoạn 1
    /** Tầm với (block) tính từ mắt. Mặc định 4.0 < 4.5 của vanilla. Hạ thấp nếu server soi chặt. */
    public double reach = 4.0;
    /** Số block tối đa đặt trong 1 tick. */
    public int blocksPerTick = 3;
    /** Cứ mỗi N tick mới đặt một đợt (1 = mỗi tick). Tăng lên để chậm lại. */
    public int placeIntervalTicks = 1;
    /** Sau bao nhiêu tick thì kiểm tra lại blockstate vừa đặt. */
    public int verifyDelayTicks = 6;
    /** Số lần thử lại một ô trước khi bỏ qua và xử lý ở cuối layer. */
    public int maxRetries = 3;
    /** Độ cao bay lơ lửng phía trên layer đang xây (chỉ chế độ bay/creative). */
    public double hoverHeight = 2.0;
    /** Tốc độ bay (block/tick). 0.25 ~ 5 block/giây. */
    public double flySpeed = 0.25;
    /** Không tiến triển sau N giây thì lập lại kế hoạch. */
    public int stuckSeconds = 8;
    /** Dừng khi máu dưới mức này. */
    public float minHealth = 6.0f;
    /** Chỉ click vào điểm mà tia nhìn từ mắt thực sự chạm tới (raycast). */
    public boolean requireRaycast = true;
    /** Góc lệch tối đa giữa hướng nhìn và điểm click. 180 = không giới hạn. */
    public double maxLookAngleDeg = 180.0;
    /** Block hơi thiếu mặt tựa thì kê giàn tạm rồi dọn đi. */
    public boolean useScaffold = true;
    public String scaffoldBlock = "minecraft:dirt";

    // ------------------------------------------------------------------ giai đoạn 2: sinh tồn
    /** true = luôn đi bộ kể cả khi đang creative (để test chế độ sinh tồn trong singleplayer). */
    public boolean forceWalk = false;
    /** Giới hạn số ô A* được duyệt cho mỗi lần tìm đường. */
    public int maxPathNodes = 6000;
    public boolean sprint = false;
    /** Số block tối đa của một cột "tháp" (nhảy + đặt block dưới chân) khi không có đường lên. */
    public int towerMax = 24;
    /** Phải nhảy cao hơn ô dưới chân bao nhiêu thì mới đặt (server có độ trễ ~1 tick). */
    public double towerMargin = 0.15;
    /** Số block giàn tối thiểu nên có trong túi (chỉ dùng khi mua /ah). */
    public int minScaffold = 16;
    /** Đói dưới mức này (0-20) thì ăn. */
    public int minFood = 12;
    public boolean autoEat = true;
    /** Chỉ ăn những món này (tránh ăn nhầm thịt thối, cá nóc...). */
    public List<String> foodItems = new ArrayList<>(List.of(
        "minecraft:cooked_beef", "minecraft:cooked_porkchop", "minecraft:cooked_mutton", "minecraft:cooked_chicken",
        "minecraft:cooked_salmon", "minecraft:cooked_cod", "minecraft:bread", "minecraft:baked_potato",
        "minecraft:golden_carrot", "minecraft:carrot", "minecraft:apple"));

    /** Mua đồ trên /ah. TẮT mặc định cho tới khi bạn điền đúng thông tin GUI (xem README, lệnh /ab ah watch). */
    public Ah ah = new Ah();

    public static final class Ah {
        public boolean enabled = false;
        /** Lệnh mở đấu giá, KHÔNG có dấu "/". */
        public String command = "ah";
        /** Nếu server có lệnh tìm kiếm, ví dụ "ah search {item}" ({item} = tên item không có minecraft:). Để trống = không dùng. */
        public String searchCommand = "";
        /** Một đoạn của tiêu đề GUI /ah (không phân biệt hoa thường). Để trống = nhận mọi GUI rương. */
        public String titleContains = "";
        /** Vùng slot chứa listing (đếm từ 0, trong phần GUI trên). -1 = toàn bộ phần trên. */
        public int itemSlotFrom = -1;
        public int itemSlotTo = -1;
        /** Slot nút trang kế. -1 = chỉ có một trang. */
        public int nextPageSlot = -1;
        /** Tên nút trang kế phải chứa đoạn này (để biết đã hết trang). Để trống = chỉ cần slot có item. */
        public String nextPageNameContains = "";
        public int maxPages = 60;
        /** Regex lấy giá từ lore/tên của listing; nhóm 1 = số tiền (hỗ trợ 1,500 / 1.5k / 2m). */
        public String pricePattern = "(?i)(?:price|gi[aá])\\s*[:：]?\\s*\\$?\\s*([0-9][0-9.,]*\\s*[kKmMbB]?)";
        /** true = giá ghi trên listing là giá của cả stack; false = giá mỗi cái. */
        public boolean priceIsPerStack = true;
        /** Slot nút xác nhận mua. -1 = server không có bảng xác nhận. */
        public int confirmSlot = -1;
        public String confirmTitleContains = "";
        /** Regex (trên tin nhắn chat) báo lỗi. Để trống = không dùng. */
        public String msgNoMoney = "";
        public String msgInvFull = "";
        public String msgGone = "";
        /** Xem số dư: lệnh (không có "/"), regex nhóm 1 = số dư. Để trống = không kiểm tra trước. */
        public String balanceCommand = "";
        public String balancePattern = "";

        public double maxPricePerBlock = 5.0;
        public double maxSpendPerBuy = 5000;
        public double maxSpendPerSession = 50000;
        /** Khi thiếu đồ ở layer hiện tại thì mua luôn cho thêm N layer tiếp theo. */
        public int buyAheadLayers = 2;
        public int maxBuyAttempts = 8;
        /** Chờ GUI mở / đổi trang tối đa bao nhiêu tick. */
        public int guiTimeoutTicks = 60;
        /** Nội dung GUI phải đứng yên bấy nhiêu tick mới đọc/click (cũng là độ trễ giữa các click). */
        public int settleTicks = 5;
        public int buyTimeoutTicks = 80;
    }

    public static Config INSTANCE = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("autobuild"); }
    public static Path schematicDir() { return dir().resolve("schematics"); }

    public static void load() {
        try {
            Files.createDirectories(schematicDir());
            Path f = dir().resolve("config.json");
            if (Files.exists(f)) {
                Config c = GSON.fromJson(Files.readString(f), Config.class);
                if (c != null) INSTANCE = c;
            }
            if (INSTANCE.ah == null) INSTANCE.ah = new Ah();
            if (INSTANCE.foodItems == null) INSTANCE.foodItems = new ArrayList<>();
            Files.writeString(f, GSON.toJson(INSTANCE)); // ghi lại để có đủ các trường mới
        } catch (Exception e) {
            System.err.println("[AutoBuild] Không đọc được config: " + e);
        }
    }
}
