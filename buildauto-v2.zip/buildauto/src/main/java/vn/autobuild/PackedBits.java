package vn.autobuild;

/** Đọc mảng bit-packed của Litematica (các phần tử nối liền nhau, có thể vắt qua ranh giới 2 long). */
public final class PackedBits {
    private PackedBits() {}

    /** Số bit mỗi phần tử theo công thức của Litematica: tối thiểu 2 bit. */
    public static int bitsFor(int paletteSize) {
        return Math.max(2, 32 - Integer.numberOfLeadingZeros(paletteSize - 1));
    }

    public static int get(long[] arr, int bits, long index) {
        long mask = (1L << bits) - 1L;
        long bitPos = index * bits;
        int w = (int) (bitPos >>> 6);
        int off = (int) (bitPos & 63);
        long v;
        if (off + bits <= 64) {
            v = (arr[w] >>> off) & mask;
        } else {
            v = ((arr[w] >>> off) | (arr[w + 1] << (64 - off))) & mask;
        }
        return (int) v;
    }
}
