package vn.autobuild;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Tìm cách đặt đúng blockstate NGAY LẦN ĐẦU, không đặt đại rồi sửa.
 * Với mỗi mặt tựa (hàng xóm) và mỗi điểm click, mô phỏng Block#getStateForPlacement bằng chính code của game
 * (BlockPlaceContext) với các hướng nhìn (yaw/pitch) khác nhau, chọn cái cho ra blockstate khớp schematic.
 * Nhờ vậy stairs/piston/observer/repeater/hopper/rail/cửa... tự đúng hướng mà không cần hard-code luật từng block.
 */
public final class PlacementSolver {
    private PlacementSolver() {}

    public record Plan(BlockHitResult hit, float yaw, float pitch) {}

    private static final float[] YAWS = {0f, 90f, 180f, 270f};      // nam, tây, bắc, đông
    private static final float[] PITCHES = {0f, 90f, -90f};         // ngang, nhìn xuống, nhìn lên

    /** Block có chức năng khi chuột phải -> không dùng làm mặt tựa (khỏi mở GUI/bật công tắc). */
    private static final String[] INTERACTIVE = {
        "crafting_table", "anvil", "cake", "composter", "cauldron", "enchanting_table", "grindstone",
        "loom", "cartography_table", "smithing_table", "stonecutter", "fletching_table", "respawn_anchor",
        "command_block", "jukebox", "lectern", "flower_pot", "bookshelf", "dragon_egg", "note_block"};

    public static Plan solve(Minecraft mc, BlockPos t, BlockState want, Vec3 eye, Config cfg) {
        ClientLevel lv = mc.level;
        LocalPlayer p = mc.player;
        if (!lv.getBlockState(t).canBeReplaced()) return null;
        ItemStack held = p.getMainHandItem();
        float oy = p.getYRot(), ox = p.getXRot();
        Plan best = null;
        double bestAng = Double.MAX_VALUE;
        try {
            for (Direction f : Direction.values()) {
                BlockPos n = t.relative(f);                 // hàng xóm làm mặt tựa
                if (!clickable(lv.getBlockState(n))) continue;
                Direction face = f.getOpposite();           // mặt của hàng xóm hướng về ô cần đặt
                double[] yOffs = face.getAxis().isHorizontal() ? new double[] {0.0, 0.25, -0.25} : new double[] {0.0};
                for (double yo : yOffs) {                   // click nửa trên/dưới để ra slab/stairs/trapdoor đúng nửa
                    Vec3 loc = n.getCenter().add(face.getStepX() * 0.5, face.getStepY() * 0.5 + yo, face.getStepZ() * 0.5);
                    if (eye.distanceTo(loc) > cfg.reach) continue;
                    if (cfg.requireRaycast && !visible(lv, p, eye, loc, n)) continue;
                    BlockHitResult hit = new BlockHitResult(loc, face, n, false);

                    float[] nat = lookAt(eye, loc);         // 1) nhìn thẳng vào điểm click (tự nhiên nhất)
                    if (works(lv, p, held, hit, want, t, nat[0], nat[1])) return new Plan(hit, nat[0], nat[1]);

                    for (float yaw : YAWS) {                // 2) xoay sang hướng khác để ra đúng blockstate
                        for (float pitch : PITCHES) {
                            double ang = angle(eye, loc, yaw, pitch);
                            if (ang > cfg.maxLookAngleDeg || ang >= bestAng) continue;
                            if (works(lv, p, held, hit, want, t, yaw, pitch)) {
                                best = new Plan(hit, yaw, pitch);
                                bestAng = ang;
                            }
                        }
                    }
                }
            }
        } finally {
            p.setYRot(oy);
            p.setXRot(ox);
        }
        return best;
    }

    private static boolean works(ClientLevel lv, LocalPlayer p, ItemStack held, BlockHitResult hit,
                                 BlockState want, BlockPos t, float yaw, float pitch) {
        try {
            p.setYRot(yaw);
            p.setXRot(pitch);
            BlockPlaceContext ctx = new BlockPlaceContext(p, InteractionHand.MAIN_HAND, held, hit);
            BlockState st = want.getBlock().getStateForPlacement(ctx);
            return st != null && StateUtil.matches(st, want, StateUtil.IGNORE_PLACE) && st.canSurvive(lv, t);
        } catch (RuntimeException e) {
            return false;
        }
    }

    static boolean clickable(BlockState s) {
        if (s.isAir() || s.canBeReplaced() || !s.getFluidState().isEmpty()) return false;
        if (s.getBlock() instanceof EntityBlock) return false;
        for (Property<?> p : s.getProperties()) {
            String n = p.getName();
            if (n.equals("open") || n.equals("powered") || n.equals("delay") || n.equals("lit")) return false;
        }
        String id = StateUtil.id(s);
        if (id.endsWith("_bed")) return false;
        for (String k : INTERACTIVE) if (id.contains(k)) return false;
        return true;
    }

    /** Tia từ mắt tới điểm click phải chạm đúng block hàng xóm (không bị block khác che). */
    private static boolean visible(ClientLevel lv, LocalPlayer p, Vec3 eye, Vec3 loc, BlockPos n) {
        Vec3 end = loc.add(loc.subtract(eye).normalize().scale(0.1));
        BlockHitResult r = lv.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return r.getType() == HitResult.Type.BLOCK && r.getBlockPos().equals(n);
    }

    static float[] lookAt(Vec3 eye, Vec3 to) {
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[] {yaw, pitch};
    }

    private static double angle(Vec3 eye, Vec3 loc, float yaw, float pitch) {
        Vec3 want = loc.subtract(eye).normalize();
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double lx = -Math.sin(yr) * Math.cos(pr), ly = -Math.sin(pr), lz = Math.cos(yr) * Math.cos(pr);
        double dot = want.x * lx + want.y * ly + want.z * lz;
        return Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, dot))));
    }
}
