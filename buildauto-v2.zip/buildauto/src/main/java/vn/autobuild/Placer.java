package vn.autobuild;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/** Thực thi: xoay đầu (gửi cả cho server), chuột phải đặt block, phá block sai, chỉnh delay repeater. */
public final class Placer {
    private Placer() {}

    public static boolean place(Minecraft mc, PlacementSolver.Plan plan) {
        return placeRaw(mc, plan.hit(), plan.yaw(), plan.pitch());
    }

    /** Đặt theo một điểm click cho trước (dùng cho cả tháp nhảy-đặt). */
    public static boolean placeRaw(Minecraft mc, BlockHitResult hit, float yaw, float pitch) {
        LocalPlayer p = mc.player;
        p.setYRot(yaw);
        p.setXRot(pitch);
        // Server tính hướng block theo góc nhìn đã nhận => phải gửi góc trước khi đặt
        p.connection.send(new ServerboundMovePlayerPacket.Rot(yaw, pitch, p.onGround(), p.horizontalCollision));
        InteractionResult r = mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, hit);
        if (r.consumesAction()) {
            p.swing(InteractionHand.MAIN_HAND);
            return true;
        }
        return false;
    }

    /**
     * Creative: phá ngay. Sinh tồn: phải GỌI LIÊN TỤC mỗi tick với cùng một ô và giữ nguyên item trên tay
     * (đổi item giữa chừng sẽ làm mất tiến độ đào) cho tới khi block biến mất.
     */
    public static void breakBlock(Minecraft mc, BlockPos pos) {
        LocalPlayer p = mc.player;
        if (p.getAbilities().instabuild) {
            mc.gameMode.destroyBlock(pos);
        } else if (!mc.gameMode.isDestroying()) {
            mc.gameMode.startDestroyBlock(pos, Direction.UP);
        } else {
            mc.gameMode.continueDestroyBlock(pos, Direction.UP);
        }
        p.swing(InteractionHand.MAIN_HAND);
    }

    /** Chuột phải lên mặt trên repeater/comparator để đổi delay/mode. */
    public static void clickFix(Minecraft mc, BlockPos pos) {
        LocalPlayer p = mc.player;
        Vec3 loc = new Vec3(pos.getX() + 0.5, pos.getY() + 0.125, pos.getZ() + 0.5);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(loc, Direction.UP, pos, false));
        p.swing(InteractionHand.MAIN_HAND);
    }
}
