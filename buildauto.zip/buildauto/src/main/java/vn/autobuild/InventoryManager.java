package vn.autobuild;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Bản đơn giản của giai đoạn 1: chọn/nạp block vào hotbar. Giai đoạn 2 sẽ mở rộng (rương, mua /ah). */
public final class InventoryManager {
    private InventoryManager() {}

    private static int rotate = 0;

    public static int count(LocalPlayer p, Item item) {
        int n = 0;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    /** true = đang cầm đúng item trên tay chính. false = chưa (hết đồ, hoặc đang chờ server cập nhật hotbar). */
    public static boolean equip(Minecraft mc, Item item) {
        LocalPlayer p = mc.player;
        Inventory inv = p.getInventory();
        if (p.getMainHandItem().is(item)) return true;

        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).is(item)) { inv.setSelectedSlot(i); return true; }
        }
        // Có trong túi chính: hoán đổi vào hotbar (chờ tick sau để server cập nhật)
        for (int i = 9; i < 36; i++) {
            if (inv.getItem(i).is(item)) {
                int hb = freeHotbarSlot(inv);
                mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, i, hb, ClickType.SWAP, p);
                inv.setSelectedSlot(hb);
                return false;
            }
        }
        // Creative: tự "lấy" item
        if (p.getAbilities().instabuild) {
            int hb = freeHotbarSlot(inv);
            ItemStack st = item.getDefaultInstance();
            inv.setItem(hb, st);
            mc.gameMode.handleCreativeModeItemAdd(st, 36 + hb);
            inv.setSelectedSlot(hb);
            return true;
        }
        return false;
    }

    private static int freeHotbarSlot(Inventory inv) {
        for (int i = 0; i < 9; i++) if (inv.getItem(i).isEmpty()) return i;
        rotate = (rotate + 1) % 9;
        return rotate;
    }
}
