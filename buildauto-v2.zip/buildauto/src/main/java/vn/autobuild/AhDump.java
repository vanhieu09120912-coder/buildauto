package vn.autobuild;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;

/**
 * Công cụ "học" GUI /ah của server: bật chế độ theo dõi rồi tự chơi /ah (đổi trang, bấm thử một listing, xác nhận...).
 * Mỗi lần nội dung GUI đổi và đứng yên, mod ghi snapshot (tiêu đề, từng slot, tên, lore) cùng các dòng chat vào
 * config/autobuild/ah_dump.txt. Gửi file đó là đủ để điền Config.ah, khỏi phải chụp ảnh.
 */
public final class AhDump {
    private AhDump() {}

    public static boolean watching;
    private static String lastFp = "", lastDumped = "";
    private static int same, n;
    private static long chatMark;

    public static Path file() { return Config.dir().resolve("ah_dump.txt"); }

    public static void start() {
        watching = true; lastFp = ""; lastDumped = ""; same = 0; n = 0;
        chatMark = ChatLog.mark();
        append("\n===== AH DUMP " + java.time.LocalDateTime.now() + " =====\n");
    }

    public static void stop() {
        watching = false;
        append("===== END =====\n");
    }

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (!watching || p == null) return;

        List<String> lines = ChatLog.since(chatMark);
        chatMark = ChatLog.mark();
        for (String l : lines) append("CHAT: " + l + "\n");

        AbstractContainerMenu m = Gui.menu(p);
        if (m == null) { lastFp = ""; same = 0; return; }
        String fp = Gui.fingerprint(m);
        if (fp.equals(lastFp)) same++; else { lastFp = fp; same = 0; }
        if (same == 6 && !fp.equals(lastDumped)) {      // đứng yên ~0.3 giây mới ghi
            lastDumped = fp;
            snapshot(mc, m);
        }
    }

    private static void snapshot(Minecraft mc, AbstractContainerMenu m) {
        n++;
        int top = Gui.top(m);
        StringBuilder sb = new StringBuilder();
        sb.append("\n--- SNAPSHOT #").append(n).append(" | title=\"").append(Gui.title(mc)).append("\" | topSlots=").append(top)
            .append(" (").append(top / 9).append(" hàng) | containerId=").append(m.containerId).append('\n');
        for (int i = 0; i < top; i++) {
            ItemStack s = m.slots.get(i).getItem();
            if (s.isEmpty()) continue;
            sb.append("slot ").append(i).append(": ").append(Gui.itemId(s)).append(" x").append(s.getCount())
                .append(" | name=\"").append(Gui.name(s)).append("\"\n");
            for (String l : Gui.lore(s)) sb.append("      lore: \"").append(l).append("\"\n");
        }
        append(sb.toString());
        BuildController.msg("§7[AH] Snapshot #" + n + ": \"" + Gui.title(mc) + "\", " + top + " slot -> " + file().getFileName());
    }

    private static void append(String s) {
        try {
            Files.createDirectories(Config.dir());
            Files.writeString(file(), s, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("[AutoBuild] Không ghi được ah_dump: " + e);
        }
    }
}
