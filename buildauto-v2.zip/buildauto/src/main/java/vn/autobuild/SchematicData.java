package vn.autobuild;

import java.util.Map;
import net.minecraft.world.level.block.state.BlockState;

/** Công trình đã đọc xong: lưới sx*sy*sz, phần tử null = không khí/bỏ qua. Index = (y*sz + z)*sx + x. */
public final class SchematicData {
    public final String name;
    public final int sx, sy, sz;
    public final BlockState[] blocks;
    /** Tên block không nhận ra (thường do schematic từ bản MC cũ/mod khác) -> số loại trong palette. */
    public final Map<String, Integer> unknown;

    public SchematicData(String name, int sx, int sy, int sz, BlockState[] blocks, Map<String, Integer> unknown) {
        this.name = name; this.sx = sx; this.sy = sy; this.sz = sz; this.blocks = blocks; this.unknown = unknown;
    }

    public BlockState get(int x, int y, int z) {
        if (x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz) return null;
        return blocks[(y * sz + z) * sx + x];
    }

    public int count() {
        int n = 0;
        for (BlockState s : blocks) if (s != null) n++;
        return n;
    }
}
