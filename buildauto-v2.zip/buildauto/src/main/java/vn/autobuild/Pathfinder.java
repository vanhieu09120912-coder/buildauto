package vn.autobuild;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Tìm đường đi bộ (A*) trên thế giới hiện tại. Mỗi node = ô CHÂN của người chơi.
 * Các bước: đi ngang, nhảy lên 1 block, rơi xuống tối đa 3 block (không mất máu). Không đi chéo, không bơi, không leo thang.
 * Chỉ đứng được trên block đặc nguyên khối (slab/stairs chưa hỗ trợ làm chỗ đứng).
 */
public final class Pathfinder {
    private Pathfinder() {}

    private static final String[] HARMFUL = {
        "fire", "cactus", "magma", "campfire", "sweet_berry", "wither_rose", "powder_snow", "cobweb", "pointed_dripstone"};
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    private static boolean harmful(BlockState s) {
        String id = StateUtil.id(s);
        for (String h : HARMFUL) if (id.contains(h)) return true;
        return false;
    }

    /** Đi xuyên qua được (không va chạm, không chất lỏng, không gây hại). */
    public static boolean passable(ClientLevel lv, BlockPos p) {
        BlockState s = lv.getBlockState(p);
        return s.getCollisionShape(lv, p).isEmpty() && s.getFluidState().isEmpty() && !harmful(s);
    }

    private static boolean floorOk(ClientLevel lv, BlockPos p) {
        BlockState s = lv.getBlockState(p);
        return s.getFluidState().isEmpty() && Block.isShapeFullBlock(s.getCollisionShape(lv, p)) && !harmful(s);
    }

    /** Đứng được ở ô chân này: chân + đầu trống, dưới chân là block đặc. */
    public static boolean standable(ClientLevel lv, BlockPos feet) {
        return passable(lv, feet) && passable(lv, feet.above()) && floorOk(lv, feet.below());
    }

    private static final class Node {
        final BlockPos pos;
        final double g, f;
        final Node parent;
        Node(BlockPos pos, double g, double f, Node parent) { this.pos = pos; this.g = g; this.f = f; this.parent = parent; }
    }

    private static double h(BlockPos a, BlockPos b) {
        return Math.max(0, Math.abs(a.getX() - b.getX()) + Math.abs(a.getZ() - b.getZ()) + Math.abs(a.getY() - b.getY()) - 3);
    }

    /**
     * @param goals tập ô chân đích (BlockPos#asLong)
     * @param hint  điểm tham chiếu cho heuristic (thường là ô cần đặt)
     * @return danh sách ô chân từ start tới đích (gồm cả start), hoặc null nếu không có đường / quá nhiều ô.
     */
    public static List<BlockPos> find(ClientLevel lv, BlockPos start, Set<Long> goals, BlockPos hint, int maxNodes) {
        if (goals.isEmpty()) return null;
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble((Node n) -> n.f));
        Map<Long, Double> best = new HashMap<>();
        open.add(new Node(start, 0, h(start, hint), null));
        best.put(start.asLong(), 0.0);
        int visited = 0;
        while (!open.isEmpty() && visited < maxNodes) {
            Node n = open.poll();
            if (n.g > best.getOrDefault(n.pos.asLong(), Double.MAX_VALUE)) continue; // bản cũ
            visited++;
            if (goals.contains(n.pos.asLong())) return rebuild(n);

            for (int[] d : DIRS) {
                BlockPos side = n.pos.offset(d[0], 0, d[1]);
                if (standable(lv, side)) {                                   // đi ngang
                    push(open, best, n, side, 1.0, hint);
                    continue;
                }
                BlockPos up = side.above();                                  // nhảy lên 1 block
                if (passable(lv, n.pos.above(2)) && standable(lv, up)) {
                    push(open, best, n, up, 2.0, hint);
                    continue;
                }
                if (passable(lv, side) && passable(lv, side.above())) {      // rơi xuống tối đa 3 block
                    for (int j = 1; j <= 3; j++) {
                        BlockPos c = side.below(j);
                        if (standable(lv, c)) { push(open, best, n, c, 1.0 + j, hint); break; }
                        if (!passable(lv, c)) break;
                    }
                }
            }
        }
        return null;
    }

    private static void push(PriorityQueue<Node> open, Map<Long, Double> best, Node from, BlockPos to, double cost, BlockPos hint) {
        double g = from.g + cost;
        long k = to.asLong();
        if (g < best.getOrDefault(k, Double.MAX_VALUE)) {
            best.put(k, g);
            open.add(new Node(to, g, g + h(to, hint), from));
        }
    }

    private static List<BlockPos> rebuild(Node n) {
        List<BlockPos> out = new ArrayList<>();
        for (Node c = n; c != null; c = c.parent) out.add(c.pos);
        Collections.reverse(out);
        return out;
    }
}
