package vn.autobuild;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

/**
 * Đọc .litematic (NBT gzip) và gộp mọi region về một lưới duy nhất.
 * Không dùng Litematica / MaLiLib. Không đụng tới Identifier/ResourceLocation nên không bị ảnh hưởng
 * bởi việc Mojang đổi tên class ở 1.21.11.
 */
public final class SchematicLoader {
    private SchematicLoader() {}

    private static Map<String, Block> byName;

    private static synchronized Map<String, Block> blocks() {
        if (byName == null) {
            byName = new HashMap<>();
            for (Block b : BuiltInRegistries.BLOCK) {
                byName.put(BuiltInRegistries.BLOCK.getKey(b).toString(), b);
            }
        }
        return byName;
    }

    /** "dirt" hoặc "minecraft:dirt" -> Block, không thấy thì null. */
    public static Block blockByName(String name) {
        if (name == null) return null;
        return blocks().get(name.contains(":") ? name : "minecraft:" + name);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> cmp(Object o) { return (Map<String, Object>) o; }

    private static int num(Map<String, Object> m, String k) { return ((Number) m.get(k)).intValue(); }

    private record Region(int ox, int oy, int oz, int sx, int sy, int sz, BlockState[] palette, long[] bits) {}

    @SuppressWarnings("unchecked")
    public static SchematicData load(Path file) throws IOException {
        String fn = file.getFileName().toString();
        if (!fn.toLowerCase().endsWith(".litematic")) {
            throw new IOException("Giai đoạn 1 chỉ hỗ trợ .litematic (.schem/.nbt sẽ thêm sau)");
        }
        Map<String, Object> root = NbtReader.readCompressed(file);
        Map<String, Object> regions = cmp(root.get("Regions"));
        if (regions == null || regions.isEmpty()) throw new IOException("File không có Regions");

        Map<String, Integer> unknown = new TreeMap<>();
        List<Region> list = new ArrayList<>();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;

        for (Object ro : regions.values()) {
            Map<String, Object> r = cmp(ro);
            Map<String, Object> pos = cmp(r.get("Position"));
            Map<String, Object> size = cmp(r.get("Size"));
            int px = num(pos, "x"), py = num(pos, "y"), pz = num(pos, "z");
            int sx = num(size, "x"), sy = num(size, "y"), sz = num(size, "z");
            // Size có thể âm: khi đó vùng kéo về phía âm so với Position
            int ox = px + (sx < 0 ? sx + 1 : 0);
            int oy = py + (sy < 0 ? sy + 1 : 0);
            int oz = pz + (sz < 0 ? sz + 1 : 0);
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);

            List<Object> palNbt = (List<Object>) r.get("BlockStatePalette");
            BlockState[] palette = new BlockState[palNbt.size()];
            for (int i = 0; i < palette.length; i++) palette[i] = parseState(cmp(palNbt.get(i)), unknown);

            long[] bits = (long[]) r.get("BlockStates");
            if (bits == null) bits = new long[0];
            list.add(new Region(ox, oy, oz, ax, ay, az, palette, bits));
            minX = Math.min(minX, ox); minY = Math.min(minY, oy); minZ = Math.min(minZ, oz);
            maxX = Math.max(maxX, ox + ax); maxY = Math.max(maxY, oy + ay); maxZ = Math.max(maxZ, oz + az);
        }

        int gx = maxX - minX, gy = maxY - minY, gz = maxZ - minZ;
        if ((long) gx * gy * gz > 200_000_000L) throw new IOException("Schematic quá lớn");
        BlockState[] out = new BlockState[gx * gy * gz];

        for (Region g : list) {
            int bitsPer = PackedBits.bitsFor(g.palette().length);
            long need = ((long) g.sx() * g.sy() * g.sz() * bitsPer + 63) / 64;
            if (g.bits().length < need) throw new IOException("BlockStates thiếu dữ liệu (file hỏng?)");
            for (int y = 0; y < g.sy(); y++) {
                for (int z = 0; z < g.sz(); z++) {
                    for (int x = 0; x < g.sx(); x++) {
                        long idx = ((long) y * g.sz() + z) * g.sx() + x;
                        int pi = PackedBits.get(g.bits(), bitsPer, idx);
                        if (pi >= g.palette().length) continue;
                        BlockState s = g.palette()[pi];
                        if (s == null || s.isAir()) continue;
                        int wx = g.ox() - minX + x, wy = g.oy() - minY + y, wz = g.oz() - minZ + z;
                        out[(wy * gz + wz) * gx + wx] = s;
                    }
                }
            }
        }
        String name = fn.substring(0, fn.length() - ".litematic".length());
        return new SchematicData(name, gx, gy, gz, out, unknown);
    }

    private static BlockState parseState(Map<String, Object> c, Map<String, Integer> unknown) {
        String name = (String) c.get("Name");
        Block b = blocks().get(name);
        if (b == null) { unknown.merge(name, 1, Integer::sum); return null; }
        BlockState s = b.defaultBlockState();
        Map<String, Object> props = cmp(c.get("Properties"));
        if (props != null) {
            for (Map.Entry<String, Object> e : props.entrySet()) {
                Property<?> p = b.getStateDefinition().getProperty(e.getKey());
                if (p != null) s = applyProp(s, p, String.valueOf(e.getValue()));
            }
        }
        return s;
    }

    private static <T extends Comparable<T>> BlockState applyProp(BlockState s, Property<T> p, String val) {
        Optional<T> v = p.getValue(val);
        return v.isPresent() ? s.setValue(p, v.get()) : s;
    }

    /** Lật gương rồi xoay (theo đúng thứ tự StructureTemplate), cả vị trí lẫn blockstate. */
    public static SchematicData transform(SchematicData d, Rotation rot, Mirror mir) {
        boolean swap = rot == Rotation.CLOCKWISE_90 || rot == Rotation.COUNTERCLOCKWISE_90;
        int nsx = swap ? d.sz : d.sx;
        int nsz = swap ? d.sx : d.sz;
        BlockState[] out = new BlockState[nsx * d.sy * nsz];
        for (int y = 0; y < d.sy; y++) {
            for (int z = 0; z < d.sz; z++) {
                for (int x = 0; x < d.sx; x++) {
                    BlockState s = d.blocks[(y * d.sz + z) * d.sx + x];
                    if (s == null) continue;
                    int mx = x, mz = z;
                    if (mir == Mirror.LEFT_RIGHT) mz = d.sz - 1 - z;       // lật theo trục Z (bắc <-> nam)
                    else if (mir == Mirror.FRONT_BACK) mx = d.sx - 1 - x;  // lật theo trục X (đông <-> tây)
                    int rx, rz;
                    switch (rot) {
                        case CLOCKWISE_90 -> { rx = d.sz - 1 - mz; rz = mx; }
                        case CLOCKWISE_180 -> { rx = d.sx - 1 - mx; rz = d.sz - 1 - mz; }
                        case COUNTERCLOCKWISE_90 -> { rx = mz; rz = d.sx - 1 - mx; }
                        default -> { rx = mx; rz = mz; }
                    }
                    out[(y * nsz + rz) * nsx + rx] = s.mirror(mir).rotate(rot);
                }
            }
        }
        return new SchematicData(d.name, nsx, d.sy, nsz, out, d.unknown);
    }
}
