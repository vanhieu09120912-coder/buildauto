package vn.autobuild;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.state.BlockState;

/** Lệnh chat: /autobuild (hoặc /ab) ... Phím tắt sẽ làm ở giai đoạn 3. */
public final class Commands {
    private Commands() {}

    private static LiteralArgumentBuilder<FabricClientCommandSource> lit(String s) {
        return ClientCommandManager.literal(s);
    }

    private static void say(CommandContext<FabricClientCommandSource> c, String s) {
        c.getSource().sendFeedback(Component.literal(s));
    }

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        BuildController b = BuildController.I;
        LiteralCommandNode<FabricClientCommandSource> root = d.register(lit("autobuild")

            .then(lit("list").executes(c -> {
                try (Stream<Path> s = Files.list(Config.schematicDir())) {
                    List<String> names = new ArrayList<>();
                    s.forEach(f -> { if (f.toString().toLowerCase().endsWith(".litematic")) names.add(f.getFileName().toString()); });
                    if (names.isEmpty()) say(c, "§eChưa có file. Bỏ .litematic vào: " + Config.schematicDir());
                    else for (String n : names) say(c, "§7- " + n);
                } catch (Exception e) { say(c, "§cLỗi: " + e); }
                return 1;
            }))

            .then(lit("load").then(ClientCommandManager.argument("file", StringArgumentType.greedyString()).executes(c -> {
                String name = StringArgumentType.getString(c, "file").trim();
                if (!name.toLowerCase().endsWith(".litematic")) name += ".litematic";
                try {
                    b.load(Config.schematicDir().resolve(name));
                    SchematicData r = b.raw;
                    say(c, "§aĐã load " + b.fileName + ": " + r.sx + "x" + r.sy + "x" + r.sz + ", " + r.count() + " block.");
                    if (!r.unknown.isEmpty()) say(c, "§eBlock không nhận ra (bị bỏ qua): " + r.unknown);
                    say(c, "§7Bước tiếp: đứng ở góc thấp nhất của chỗ xây rồi gõ /autobuild anchor");
                } catch (Exception e) { say(c, "§cKhông load được: " + e.getMessage()); }
                return 1;
            })))

            .then(lit("anchor")
                .executes(c -> {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.player == null) return 0;
                    b.anchor = mc.player.blockPosition();
                    say(c, "§aGốc = " + b.anchor.toShortString() + " (góc X,Y,Z nhỏ nhất của công trình)");
                    return 1;
                })
                .then(ClientCommandManager.argument("x", IntegerArgumentType.integer())
                    .then(ClientCommandManager.argument("y", IntegerArgumentType.integer())
                        .then(ClientCommandManager.argument("z", IntegerArgumentType.integer()).executes(c -> {
                            b.anchor = new BlockPos(IntegerArgumentType.getInteger(c, "x"),
                                IntegerArgumentType.getInteger(c, "y"), IntegerArgumentType.getInteger(c, "z"));
                            say(c, "§aGốc = " + b.anchor.toShortString());
                            return 1;
                        })))))

            .then(lit("rotate").then(ClientCommandManager.argument("deg", IntegerArgumentType.integer(0, 360)).executes(c -> {
                int deg = IntegerArgumentType.getInteger(c, "deg") % 360;
                if (deg % 90 != 0) { say(c, "§cChỉ nhận 0/90/180/270"); return 0; }
                b.rotDeg = deg;
                say(c, "§aXoay " + deg + "° (áp dụng ở lần /autobuild start kế tiếp)");
                return 1;
            })))

            .then(lit("mirror")
                .then(lit("none").executes(c -> { b.mirror = Mirror.NONE; say(c, "§aKhông lật gương"); return 1; }))
                .then(lit("x").executes(c -> { b.mirror = Mirror.FRONT_BACK; say(c, "§aLật theo trục X (đông<->tây)"); return 1; }))
                .then(lit("z").executes(c -> { b.mirror = Mirror.LEFT_RIGHT; say(c, "§aLật theo trục Z (bắc<->nam)"); return 1; })))

            .then(lit("materials").executes(c -> {
                Minecraft mc = Minecraft.getInstance();
                if (b.raw == null) { say(c, "§cChưa load schematic"); return 0; }
                Map<Item, Integer> need = new LinkedHashMap<>();
                for (BlockState s : b.raw.blocks) {
                    if (s == null || BuildPlanner.skipReason(s) != null) continue;
                    need.merge(s.getBlock().asItem(), 1, Integer::sum);
                }
                List<Map.Entry<Item, Integer>> rows = new ArrayList<>(need.entrySet());
                rows.sort((x, y) -> y.getValue() - x.getValue());
                say(c, "§6Vật liệu (cần | có | thiếu):");
                int shown = 0;
                for (Map.Entry<Item, Integer> e : rows) {
                    int have = mc.player == null ? 0 : InventoryManager.count(mc.player, e.getKey());
                    int miss = Math.max(0, e.getValue() - have);
                    if (++shown <= 25) say(c, "§7" + BuiltInRegistries.ITEM.getKey(e.getKey()) + ": " + e.getValue() + " | " + have + " | " + (miss > 0 ? "§c" + miss : "§a0"));
                }
                if (rows.size() > 25) say(c, "§7... và " + (rows.size() - 25) + " loại nữa");
                return 1;
            }))

            .then(lit("start").executes(c -> {
                String err = b.start();
                if (err != null) say(c, "§c" + err);
                else {
                    say(c, "§aBắt đầu xây: " + b.planner.total + " block, " + b.planner.layers.size() + " layer.");
                    if (!b.planner.skipped.isEmpty()) say(c, "§7Bỏ qua/tự sinh: " + b.planner.skipped);
                }
                return 1;
            }))
            .then(lit("pause").executes(c -> { b.pause("do bạn yêu cầu"); return 1; }))
            .then(lit("resume").executes(c -> { String e = b.resume(); say(c, e == null ? "§aTiếp tục" : "§c" + e); return 1; }))
            .then(lit("stop").executes(c -> { b.stop(); say(c, "§eĐã dừng"); return 1; }))
            .then(lit("status").executes(c -> { say(c, "§b" + b.statusText()); return 1; }))
            .then(lit("layer").then(ClientCommandManager.argument("n", IntegerArgumentType.integer(1)).executes(c -> {
                String e = b.gotoLayer(IntegerArgumentType.getInteger(c, "n"));
                say(c, e == null ? "§aNhảy tới layer " + IntegerArgumentType.getInteger(c, "n") : "§c" + e);
                return 1;
            })))
            .then(lit("reload").executes(c -> { Config.load(); say(c, "§aĐã nạp lại config"); return 1; }))

            // ---- giai đoạn 2: sinh tồn
            .then(lit("walk")
                .then(lit("on").executes(c -> { Config.INSTANCE.forceWalk = true; say(c, "§aLuôn đi bộ (kể cả creative). Đang bay thì hạ xuống đất."); return 1; }))
                .then(lit("off").executes(c -> { Config.INSTANCE.forceWalk = false; say(c, "§aTự chọn: có quyền bay thì bay, sinh tồn thì đi bộ"); return 1; })))
            .then(lit("cleanup").executes(c -> { String e = b.cleanup(); say(c, e == null ? "§aĐang dọn giàn tháp" : "§c" + e); return 1; }))
            .then(lit("ah")
                .then(lit("watch")
                    .then(lit("on").executes(c -> {
                        AhDump.start();
                        say(c, "§aĐang ghi GUI /ah vào " + AhDump.file() + ". Giờ hãy gõ /ah, lật 1-2 trang, bấm thử 1 listing (tới bảng xác nhận thì thôi, đừng xác nhận nếu không muốn mua), rồi /ab ah watch off");
                        return 1;
                    }))
                    .then(lit("off").executes(c -> { AhDump.stop(); say(c, "§aĐã dừng. Gửi file: " + AhDump.file()); return 1; })))
                .then(lit("buy").then(ClientCommandManager.argument("item", StringArgumentType.word())
                    .then(ClientCommandManager.argument("count", IntegerArgumentType.integer(1)).executes(c -> {
                        Item it = InventoryManager.itemByName(StringArgumentType.getString(c, "item"));
                        if (it == null) { say(c, "§cKhông biết item này (ví dụ: cobblestone hoặc minecraft:cobblestone)"); return 0; }
                        String e = b.manualBuy(it, IntegerArgumentType.getInteger(c, "count"));
                        say(c, e == null ? "§aBắt đầu mua thử trên /ah" : "§c" + e);
                        return 1;
                    })))))
        );
        d.register(lit("ab").redirect(root));
    }
}
