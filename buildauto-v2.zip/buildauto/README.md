# BuildAuto (Fabric, client-side) — Giai đoạn 2: SINH TỒN + khung mua /ah

Mod client tự đọc `.litematic` và tự xây theo từng layer. Không dùng Litematica/MaLiLib/Tweakeroo.
Bản 0.2.0 thêm chế độ sinh tồn để chơi được trên server: **đi bộ thật** (không bay), tự ăn, đào đúng cách, tự mua đồ trên /ah.

## Build ra .jar bằng GitHub Actions (Minecraft 1.21.11, Java 21)
Không cần cài Java/Gradle trên máy. Workflow `.github/workflows/build.yml` giải nén `buildauto-v2.zip` trong repo rồi build.
1. Upload file zip này lên repo `buildauto` (Add file → Upload files) rồi Commit.
2. Tab **Actions** → chờ lần chạy **Build** có dấu tick xanh → mục **Artifacts** → tải `buildauto-jar` → giải nén ra `buildauto-0.2.0.jar`.
3. Bỏ jar + Fabric API vào `mods`.
4. **Chưa có ai biên dịch bản này với jar Minecraft thật.** Nếu build đỏ, copy phần log lỗi gửi lại.
   Các API mới dùng lần đầu (không có ở giai đoạn 1): `ClientPacketListener#sendCommand(String)`, `ClientReceiveMessageEvents.GAME`,
   `ItemStack#get(DataComponents.LORE)` + `ItemLore#lines()`, `Item#getDefaultMaxStackSize()`, `FoodData#getFoodLevel()`,
   `KeyMapping#setDown`, `MultiPlayerGameMode#useItem`, `LocalPlayer#closeContainer()`.

## Có gì mới
| Phần | Việc làm |
|---|---|
| `Pathfinder` + `StandFinder` + `Walker` | A* đi bộ: đi ngang, nhảy lên 1 block, rơi tối đa 3 block. Chọn chỗ đứng trong tầm với mà `PlacementSolver` xác nhận đặt đúng blockstate được. Bấm phím tiến/nhảy như người chơi (server thấy gói di chuyển bình thường). |
| Tháp nhảy-đặt (`Walker.towerTick`) | Khi không có đường lên ô cao: nhìn xuống, nhảy, đặt block dưới chân. Cột giàn được ghi nhớ và dọn từ trên xuống ở cuối (`/ab cleanup`). |
| Đào sinh tồn | Block sai / giàn tạm: giữ nguyên dụng cụ (tự chọn nhanh nhất trong hotbar) tới khi vỡ, không đổi item giữa chừng. |
| `Survival` | Đói dưới `minFood` thì tự ăn món trong `foodItems`; hết đồ ăn thì dừng. Chết / máu thấp / mất kết nối thì dừng. |
| `Materials` | Tính thiếu bao nhiêu cho layer hiện tại + `buyAheadLayers` layer sau, rút gọn theo số ô trống trong túi. |
| `AuctionBuyer` | State machine mua /ah: đọc hết các trang → chọn giá mỗi cái rẻ nhất trong giới hạn → mở lại, lật tới đúng trang, kiểm tra listing còn y nguyên → click (→ xác nhận) → chờ item vào túi → lỗi thì loại listing, thử cái kế. |
| `AhDump` | Công cụ "học" GUI /ah của server (xem bên dưới). |

/ah là lệnh mở GUI từ xa nên **không cần đi đâu cả**: mod dừng xây, mua, rồi xây tiếp ngay tại chỗ.

## Test chế độ sinh tồn (singleplayer trước, rồi mới lên server)
**Test 1, đi bộ (creative cũng test được):**
1. Thế giới superflat, creative. `/ab walk on`, đứng xuống đất (không bay).
2. `/ab load <tên>`, `/ab anchor`, `/ab start`. Nhân vật phải đi bộ quanh công trình, nhảy lên block đã đặt, xây tới layer cuối.
**Test 2, sinh tồn thật:** thế giới survival (bật cheat để `/give`):
1. Cho vật liệu `/ab materials` báo đủ + 16 dirt (giàn) + vài món ăn + 1 cúp/xẻng trong hotbar. `/ab start`.
2. Quan sát: tự ăn khi đói (`minFood`), hết một loại block thì dừng báo rõ loại nào (vì `ah.enabled=false`), bỏ thêm vào rồi `/ab resume`.
3. Công trình có ô lơ lửng cao: xem tháp có dựng và cuối cùng có dọn không.

## Cấu hình mua /ah (TẮT cho tới khi bạn điền)
Mọi thứ phụ thuộc plugin của server nằm trong `config.json` → `"ah"`. Mod **không đoán** GUI của server. Cách điền chuẩn:
1. Vào server, gõ `/ab ah watch on`
2. Gõ `/ah`, lật 1–2 trang, bấm thử một listing để ra bảng xác nhận (đừng xác nhận nếu chưa muốn mua), thử mua 1 món rẻ nếu được (để ghi lại tin nhắn chat khi mua), rồi gõ `/bal`.
3. `/ab ah watch off`. File `config/autobuild/ah_dump.txt` chứa tiêu đề GUI, từng slot, tên, lore và các dòng chat. **Gửi file đó cho mình** → mình điền đúng `ah` và test lại.

Ví dụ minh hoạ (số liệu giả, KHÔNG dùng nguyên):
```json
"ah": {
  "enabled": true,
  "command": "ah",
  "titleContains": "Auction",
  "itemSlotFrom": 0, "itemSlotTo": 44,
  "nextPageSlot": 53, "nextPageNameContains": "Next",
  "pricePattern": "(?i)price:\\s*\\$?([0-9][0-9.,]*\\s*[kKmMbB]?)",
  "priceIsPerStack": true,
  "confirmSlot": 11, "confirmTitleContains": "Confirm",
  "msgNoMoney": "(?i)not enough", "msgInvFull": "(?i)inventory.*full",
  "balanceCommand": "bal", "balancePattern": "(?i)balance:\\s*\\$?([0-9][0-9.,]*[kKmMbB]?)",
  "maxPricePerBlock": 5.0, "maxSpendPerBuy": 5000, "maxSpendPerSession": 50000
}
```
Thử riêng module mua: `/ab ah buy cobblestone 64`. Vượt giới hạn giá/tiền thì dừng và báo, không tự mua tiếp.

## Lệnh mới
`/ab walk on|off` · `/ab cleanup` · `/ab ah watch on|off` · `/ab ah buy <item> <số lượng>`
(các lệnh cũ giữ nguyên: list, load, anchor, rotate, mirror, materials, start, pause, resume, stop, status, layer N, reload)

## Config sinh tồn mới (`config.json`)
`forceWalk`, `maxPathNodes`, `sprint`, `towerMax`, `towerMargin`, `minScaffold`, `minFood`, `autoEat`, `foodItems`, và khối `ah`.
Server có anti-cheat: tăng `placeIntervalTicks`, giảm `blocksPerTick` và `reach` (ví dụ 3.5), để `sprint=false`.

## Giới hạn đã biết (làm sau)
- Chỗ đứng chỉ là block đặc nguyên khối (slab/stairs chưa đứng được); không bơi, không leo thang/dây leo; không cầu (bridge) ngang qua khoảng trống.
- Tháp chỉ dựng ở cột đang đứng và chỉ khi cột đó không thuộc công trình; ô lơ lửng xa hơn 1 ô so với block đặc vẫn có thể thất bại (sẽ báo cuối layer).
- Nước/lava bằng xô, slab đôi, rương/shulker làm nguồn đồ, .schem/.nbt: chưa có.
- Nếu /ah của server giao hàng qua "claim/mailbox" thay vì vào túi ngay, mod chưa nhận ra (dump sẽ cho biết).
- Chưa có phím tắt/HUD đẹp/lưu tiến độ (giai đoạn 3).
- Rotation đổi tức thời khi đặt block: server soi chặt có thể phát hiện.

## Cấu trúc
`NbtReader`, `PackedBits`, `SchematicLoader`, `BuildPlanner`, `PlacementSolver` (như giai đoạn 1) ·
`BuildController` (vòng lặp, trạng thái IDLE/BUILDING/PAUSED/BUYING/CLEANUP/DONE) · `Pathfinder`, `StandFinder`, `Walker`, `PathMover` (bay, creative) ·
`Placer`, `InventoryManager`, `Survival`, `Materials` · `AuctionBuyer`, `AhDump`, `Gui`, `ChatLog` · `Commands`, `Config`.
