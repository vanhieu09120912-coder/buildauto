package vn.autobuild;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Tự mua đồ trên /ah. Mọi thứ phụ thuộc server nằm ở Config.ah (tên GUI, slot, regex giá...).
 * Quy trình cho mỗi món: mở /ah -> đọc HẾT các trang -> chọn listing rẻ nhất (giá mỗi cái) trong giới hạn an toàn ->
 * mở lại /ah, lật tới đúng trang, kiểm tra listing còn y nguyên -> click mua (-> xác nhận) -> chờ item vào túi.
 * Không đủ số lượng thì lặp lại. Lỗi (đã bị mua, không vào túi...) thì loại listing đó và thử cái kế.
 * Chạy bằng state machine, mỗi tick một bước nhỏ, giữa các click luôn chờ GUI đứng yên (settleTicks).
 */
public final class AuctionBuyer {
    public enum Result { RUNNING, DONE, FAILED }

    private enum Ph { START, BALANCE, OPEN, WAIT_GUI, SCAN, WAIT_PAGE, NAV, WAIT_NAV, CLICK, WAIT_CONFIRM, WAIT_RESULT }

    private record Listing(int page, int slot, double total, int count, String sig) {
        double unit() { return total / Math.max(1, count); }
    }

    /** Tổng tiền đã chi trong phiên chơi (reset khi tắt game). */
    public static double sessionSpent;
    /** Tiền đã chi trong lần chạy này. */
    public double spent;
    public String failReason = "";

    private final Deque<Map.Entry<Item, Integer>> jobs = new ArrayDeque<>();
    private Item item;
    private int target;                       // số lượng muốn có trong túi khi xong món này
    private Ph ph = Ph.START;
    private int t;                            // tick trong pha hiện tại
    private Pattern pricePat;
    private final Set<String> blacklist = new HashSet<>();
    private final List<Listing> listings = new ArrayList<>();
    private int page, navLeft, attempts, unparsed;
    private boolean navigating;
    private Listing best;
    private String fpBefore = "", lastFp = "";
    private int sameTicks;
    private int haveBefore;
    private long chatMark;
    private double balance = -1;

    public AuctionBuyer(Map<Item, Integer> missing) {
        for (Map.Entry<Item, Integer> e : missing.entrySet()) if (e.getValue() > 0) jobs.add(e);
    }

    public String currentItemName() { return item == null ? "" : Gui.itemId(item.getDefaultInstance()); }

    /** Huỷ: đóng GUI nếu đang mở. */
    public void abort(Minecraft mc) {
        if (mc.player != null && Gui.menu(mc.player) != null) mc.player.closeContainer();
    }

    private void go(Ph next) { ph = next; t = 0; }

    private Result fail(String why) { failReason = why; return Result.FAILED; }

    public Result tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) return fail("mất kết nối");
        Config.Ah ah = Config.INSTANCE.ah;
        t++;
        switch (ph) {
            case START -> {
                if (jobs.isEmpty()) return Result.DONE;
                Map.Entry<Item, Integer> e = jobs.poll();
                item = e.getKey();
                target = InventoryManager.count(p, item) + e.getValue();
                blacklist.clear(); attempts = 0; navigating = false;
                try { pricePat = Pattern.compile(ah.pricePattern); }
                catch (PatternSyntaxException ex) { return fail("ah.pricePattern không phải regex hợp lệ"); }
                if (!ah.balanceCommand.isBlank()) go(Ph.BALANCE); else go(Ph.OPEN);
            }
            case BALANCE -> {
                if (t == 1) { chatMark = ChatLog.mark(); p.connection.sendCommand(ah.balanceCommand); }
                if (!ah.balancePattern.isBlank()) {
                    for (String line : ChatLog.since(chatMark)) {
                        Matcher m = Pattern.compile(ah.balancePattern).matcher(line);
                        if (m.find()) { balance = parseMoney(m.group(1)); BuildController.msg("§7[AH] Số dư: " + balance); go(Ph.OPEN); return Result.RUNNING; }
                    }
                }
                if (t > 60) { balance = -1; go(Ph.OPEN); }   // không đọc được số dư thì bỏ qua bước kiểm tra này
            }
            case OPEN -> {
                if (Gui.menu(p) != null) { p.closeContainer(); if (t < 3) return Result.RUNNING; }
                if (attempts > ah.maxBuyAttempts) return fail("thử quá " + ah.maxBuyAttempts + " lần mà chưa mua được " + currentItemName());
                String cmd = ah.searchCommand.isBlank() ? ah.command : ah.searchCommand.replace("{item}", shortName());
                lastFp = ""; sameTicks = 0;
                p.connection.sendCommand(cmd);
                listings.clear(); page = 0; unparsed = 0;
                go(Ph.WAIT_GUI);
            }
            case WAIT_GUI -> {
                AbstractContainerMenu m = Gui.menu(p);
                if (m != null && titleOk(mc, ah.titleContains) && stable(m, ah.settleTicks)) {
                    go(navigating ? Ph.NAV : Ph.SCAN);
                } else if (t > ah.guiTimeoutTicks) {
                    return fail("không mở được GUI /ah (kiểm tra ah.command / ah.titleContains)");
                }
            }
            case SCAN -> {
                AbstractContainerMenu m = Gui.menu(p);
                if (m == null) { if (t > ah.guiTimeoutTicks) return fail("GUI /ah đóng giữa chừng"); return Result.RUNNING; }
                if (!stable(m, ah.settleTicks)) return Result.RUNNING;
                collect(m, ah);
                if (hasNext(m, ah) && page < ah.maxPages) {
                    fpBefore = Gui.fingerprint(m);
                    Gui.click(mc, p, m, ah.nextPageSlot);
                    lastFp = ""; sameTicks = 0;
                    go(Ph.WAIT_PAGE);
                } else {
                    return decide(mc, ah);
                }
            }
            case WAIT_PAGE -> {
                AbstractContainerMenu m = Gui.menu(p);
                if (m != null && !Gui.fingerprint(m).equals(fpBefore)) { page++; go(Ph.SCAN); }
                else if (t > ah.guiTimeoutTicks) return decide(mc, ah);   // trang không đổi = đã hết trang
            }
            case NAV -> {
                AbstractContainerMenu m = Gui.menu(p);
                if (m == null) { if (t > ah.guiTimeoutTicks) { attempts++; navigating = false; go(Ph.OPEN); } return Result.RUNNING; }
                if (!stable(m, ah.settleTicks)) return Result.RUNNING;
                if (navLeft <= 0) { go(Ph.CLICK); return Result.RUNNING; }
                fpBefore = Gui.fingerprint(m);
                Gui.click(mc, p, m, ah.nextPageSlot);
                lastFp = ""; sameTicks = 0;
                go(Ph.WAIT_NAV);
            }
            case WAIT_NAV -> {
                AbstractContainerMenu m = Gui.menu(p);
                if (m != null && !Gui.fingerprint(m).equals(fpBefore)) { navLeft--; go(Ph.NAV); }
                else if (t > ah.guiTimeoutTicks) { attempts++; go(Ph.OPEN); }
            }
            case CLICK -> {
                AbstractContainerMenu m = Gui.menu(p);
                if (m == null) { if (t > ah.guiTimeoutTicks) { attempts++; navigating = false; go(Ph.OPEN); } return Result.RUNNING; }
                if (!stable(m, ah.settleTicks)) return Result.RUNNING;
                ItemStack st = best.slot() < Gui.top(m) ? m.slots.get(best.slot()).getItem() : ItemStack.EMPTY;
                if (st.isEmpty() || !st.is(item) || !best.sig().equals(sigOf(st, st.getCount(), ah))) {
                    attempts++; navigating = false;   // listing đã dịch chỗ/biến mất -> quét lại
                    BuildController.msg("§e[AH] Listing đã đổi, quét lại");
                    go(Ph.OPEN);
                    return Result.RUNNING;
                }
                haveBefore = InventoryManager.count(p, item);
                chatMark = ChatLog.mark();
                fpBefore = Gui.fingerprint(m);
                Gui.click(mc, p, m, best.slot());
                go(ah.confirmSlot >= 0 ? Ph.WAIT_CONFIRM : Ph.WAIT_RESULT);
            }
            case WAIT_CONFIRM -> {
                AbstractContainerMenu m = Gui.menu(p);
                if (m != null && !Gui.fingerprint(m).equals(fpBefore) && titleOk(mc, ah.confirmTitleContains) && stable(m, ah.settleTicks)) {
                    if (ah.confirmSlot < Gui.top(m) && !m.slots.get(ah.confirmSlot).getItem().isEmpty()) {
                        Gui.click(mc, p, m, ah.confirmSlot);
                        go(Ph.WAIT_RESULT);
                        return Result.RUNNING;
                    }
                }
                if (t > ah.guiTimeoutTicks) { return retryWithout(best); }
            }
            case WAIT_RESULT -> {
                int have = InventoryManager.count(p, item);
                if (have > haveBefore) {                                    // mua được -> item đã vào túi
                    spent += best.total();
                    sessionSpent += best.total();
                    BuildController.msg("§a[AH] Mua " + (have - haveBefore) + " " + currentItemName() + " giá " + best.total() + " (tổng phiên " + sessionSpent + ")");
                    if (Gui.menu(p) != null) p.closeContainer();
                    navigating = false;
                    if (have >= target) go(Ph.START); else go(Ph.OPEN);
                    return Result.RUNNING;
                }
                for (String line : ChatLog.since(chatMark)) {
                    if (matches(ah.msgNoMoney, line)) return fail("không đủ tiền");
                    if (matches(ah.msgInvFull, line)) return fail("túi đầy");
                    if (matches(ah.msgGone, line)) return retryWithout(best);
                }
                if (t > ah.buyTimeoutTicks) return retryWithout(best);
            }
        }
        return Result.RUNNING;
    }

    // ------------------------------------------------------------------ các bước con

    private Result retryWithout(Listing l) {
        blacklist.add(l.sig());
        attempts++;
        navigating = false;
        BuildController.msg("§e[AH] Mua không được listing này, thử listing khác");
        go(Ph.OPEN);
        return Result.RUNNING;
    }

    private Result decide(Minecraft mc, Config.Ah ah) {
        double budget = Math.min(ah.maxSpendPerBuy, ah.maxSpendPerSession - sessionSpent);
        if (balance >= 0) budget = Math.min(budget, balance - spent);
        Listing pick = null;
        double cheapest = Double.MAX_VALUE;
        for (Listing l : listings) {
            cheapest = Math.min(cheapest, l.unit());
            if (blacklist.contains(l.sig())) continue;
            if (l.unit() > ah.maxPricePerBlock) continue;
            if (l.total() > budget) continue;
            if (pick == null || l.unit() < pick.unit()) pick = l;
        }
        if (pick == null) {
            if (listings.isEmpty()) return fail("không thấy listing nào của " + currentItemName()
                + (unparsed > 0 ? " (có " + unparsed + " listing đọc không ra giá: kiểm tra ah.pricePattern)" : ""));
            return fail("không có listing hợp lệ trong giới hạn (rẻ nhất " + cheapest + "/cái; giới hạn " + ah.maxPricePerBlock
                + "/cái, ngân sách còn " + budget + ")");
        }
        best = pick;
        BuildController.msg("§7[AH] Chọn listing " + pick.count() + " cái giá " + pick.total() + " (" + String.format("%.2f", pick.unit()) + "/cái), trang " + (pick.page() + 1));
        navLeft = pick.page();
        navigating = true;
        go(Ph.OPEN);
        return Result.RUNNING;
    }

    private void collect(AbstractContainerMenu m, Config.Ah ah) {
        int top = Gui.top(m);
        int from = ah.itemSlotFrom < 0 ? 0 : ah.itemSlotFrom;
        int to = ah.itemSlotTo < 0 ? top - 1 : Math.min(ah.itemSlotTo, top - 1);
        for (int i = from; i <= to; i++) {
            ItemStack s = m.slots.get(i).getItem();
            if (s.isEmpty() || !s.is(item)) continue;
            String ptxt = findPrice(s);
            if (ptxt == null) { unparsed++; continue; }
            double total = parseMoney(ptxt);
            if (Double.isNaN(total)) { unparsed++; continue; }
            if (!ah.priceIsPerStack) total *= s.getCount();
            listings.add(new Listing(page, i, total, s.getCount(), sigOf(s, s.getCount(), ah)));
        }
    }

    private String findPrice(ItemStack s) {
        List<String> lines = Gui.lore(s);
        lines.add(0, Gui.name(s));
        for (String line : lines) {
            Matcher m = pricePat.matcher(line);
            if (m.find()) return m.group(1);
        }
        return null;
    }

    /** Chữ ký listing = item + số lượng + chuỗi giá (không dùng tên người bán/thời gian hết hạn vì thay đổi theo phút). */
    private String sigOf(ItemStack s, int count, Config.Ah ah) {
        String p = findPrice(s);
        return Gui.itemId(s) + "|" + count + "|" + (p == null ? "?" : p.replace(" ", ""));
    }

    private boolean hasNext(AbstractContainerMenu m, Config.Ah ah) {
        if (ah.nextPageSlot < 0 || ah.nextPageSlot >= Gui.top(m)) return false;
        ItemStack s = m.slots.get(ah.nextPageSlot).getItem();
        if (s.isEmpty()) return false;
        return ah.nextPageNameContains.isBlank()
            || Gui.name(s).toLowerCase().contains(ah.nextPageNameContains.toLowerCase());
    }

    private boolean stable(AbstractContainerMenu m, int need) {
        String f = Gui.fingerprint(m);
        if (f.equals(lastFp)) sameTicks++; else { lastFp = f; sameTicks = 0; }
        return sameTicks >= need;
    }

    private static boolean titleOk(Minecraft mc, String contains) {
        return contains.isBlank() || Gui.title(mc).toLowerCase().contains(contains.toLowerCase());
    }

    private static boolean matches(String regex, String line) {
        if (regex == null || regex.isBlank()) return false;
        try { return Pattern.compile(regex).matcher(line).find(); }
        catch (PatternSyntaxException e) { return false; }
    }

    private String shortName() {
        String id = Gui.itemId(item.getDefaultInstance());
        return id.substring(id.indexOf(':') + 1);
    }

    /** "1,500" / "1.500" / "1.5k" / "2m" / "3,25" -> số. NaN nếu không đọc được. */
    public static double parseMoney(String raw) {
        String s = raw.trim().replace(" ", "");
        if (s.isEmpty()) return Double.NaN;
        double mult = 1;
        char last = Character.toLowerCase(s.charAt(s.length() - 1));
        if (last == 'k') mult = 1e3; else if (last == 'm') mult = 1e6; else if (last == 'b') mult = 1e9;
        if (mult != 1) s = s.substring(0, s.length() - 1);
        if (s.matches("\\d{1,3}(,\\d{3})+(\\.\\d+)?")) s = s.replace(",", "");          // 1,500.25
        else if (s.matches("\\d{1,3}(\\.\\d{3})+(,\\d+)?")) s = s.replace(".", "").replace(',', '.'); // 1.500,25
        else s = s.replace(',', '.');                                                    // 3,25
        try { return Double.parseDouble(s) * mult; }
        catch (NumberFormatException e) { return Double.NaN; }
    }
}
