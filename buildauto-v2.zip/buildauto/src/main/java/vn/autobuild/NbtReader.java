package vn.autobuild;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Bộ đọc NBT nén gzip tự viết (không dùng NbtIo của game) để không phụ thuộc mapping/phiên bản.
 * Kết quả: Map (compound), List (list), long[]/int[]/byte[] (mảng), Number, String.
 */
public final class NbtReader {
    private NbtReader() {}

    public static Map<String, Object> readCompressed(Path file) throws IOException {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(
                new GZIPInputStream(Files.newInputStream(file), 65536), 65536))) {
            int type = in.readUnsignedByte();
            if (type != 10) throw new IOException("Gốc NBT phải là compound (file không đúng định dạng?)");
            in.readUTF(); // tên gốc, bỏ qua
            return readCompound(in);
        }
    }

    private static Map<String, Object> readCompound(DataInputStream in) throws IOException {
        Map<String, Object> m = new LinkedHashMap<>();
        while (true) {
            int t = in.readUnsignedByte();
            if (t == 0) return m;
            String name = in.readUTF();
            m.put(name, readPayload(in, t));
        }
    }

    private static Object readPayload(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: {
                byte[] b = new byte[in.readInt()];
                in.readFully(b);
                return b;
            }
            case 8: return in.readUTF();
            case 9: {
                int elemType = in.readUnsignedByte();
                int n = in.readInt();
                List<Object> list = new ArrayList<>(Math.max(n, 0));
                for (int i = 0; i < n; i++) list.add(readPayload(in, elemType));
                return list;
            }
            case 10: return readCompound(in);
            case 11: {
                int[] a = new int[in.readInt()];
                for (int i = 0; i < a.length; i++) a[i] = in.readInt();
                return a;
            }
            case 12: {
                long[] a = new long[in.readInt()];
                for (int i = 0; i < a.length; i++) a[i] = in.readLong();
                return a;
            }
            default: throw new IOException("Kiểu NBT lạ: " + type);
        }
    }
}
